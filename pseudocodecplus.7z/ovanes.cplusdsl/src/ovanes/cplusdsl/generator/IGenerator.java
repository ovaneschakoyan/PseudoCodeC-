package ovanes.cplusdsl.generator;

public interface IGenerator {

}
