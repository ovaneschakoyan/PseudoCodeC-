package ovanes.cplusdsl.generator;

public class CallFunctionImpl {

}
