package ovanes.cplusdsl.generator;

public class MethodImpl {

}
