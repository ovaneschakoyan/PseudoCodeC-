package ovanes.cplusdsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import ovanes.cplusdsl.services.CplusGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalCplusParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_CAR", "RULE_STRING", "RULE_ID", "RULE_MATRIX", "RULE_CAD", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'initiation'", "'endinitiation'", "','", "'('", "')'", "'='", "'write'", "'read'", "'if'", "'then'", "'endif'", "'while'", "'repeat'", "'endwhile'", "'when'", "'endrepeat'", "'from'", "'to'", "'tohave'", "'endfor'", "'integer'", "'character'", "'decimal'", "'boolean'", "'string'", "'-'", "'.'", "'E'", "'e'", "'true'", "'false'", "'+'", "'*'", "'/'", "'<'", "'>'", "'>='", "'<='", "'y'", "'o'", "'=='", "'!='", "'elseif'", "'++'", "'--'", "'function'", "'return'", "'endfunction'", "'method'", "'endmethod'", "'E/S'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=9;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=10;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_CAR=4;
    public static final int RULE_SL_COMMENT=11;
    public static final int RULE_MATRIX=7;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CAD=8;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=12;
    public static final int RULE_ANY_OTHER=13;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalCplusParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalCplusParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalCplusParser.tokenNames; }
    public String getGrammarFileName() { return "InternalCplus.g"; }



     	private CplusGrammarAccess grammarAccess;

        public InternalCplusParser(TokenStream input, CplusGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Code";
       	}

       	@Override
       	protected CplusGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleCode"
    // InternalCplus.g:64:1: entryRuleCode returns [EObject current=null] : iv_ruleCode= ruleCode EOF ;
    public final EObject entryRuleCode() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCode = null;


        try {
            // InternalCplus.g:64:45: (iv_ruleCode= ruleCode EOF )
            // InternalCplus.g:65:2: iv_ruleCode= ruleCode EOF
            {
             newCompositeNode(grammarAccess.getCodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCode=ruleCode();

            state._fsp--;

             current =iv_ruleCode; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCode"


    // $ANTLR start "ruleCode"
    // InternalCplus.g:71:1: ruleCode returns [EObject current=null] : ( ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )? ( (lv_has_2_0= ruleInitiation ) ) ) ;
    public final EObject ruleCode() throws RecognitionException {
        EObject current = null;

        EObject lv_function_0_0 = null;

        EObject lv_function_1_0 = null;

        EObject lv_has_2_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:77:2: ( ( ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )? ( (lv_has_2_0= ruleInitiation ) ) ) )
            // InternalCplus.g:78:2: ( ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )? ( (lv_has_2_0= ruleInitiation ) ) )
            {
            // InternalCplus.g:78:2: ( ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )? ( (lv_has_2_0= ruleInitiation ) ) )
            // InternalCplus.g:79:3: ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )? ( (lv_has_2_0= ruleInitiation ) )
            {
            // InternalCplus.g:79:3: ( ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )* )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==59||LA2_0==62) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalCplus.g:80:4: ( (lv_function_0_0= ruleThread ) ) ( (lv_function_1_0= ruleThread ) )*
                    {
                    // InternalCplus.g:80:4: ( (lv_function_0_0= ruleThread ) )
                    // InternalCplus.g:81:5: (lv_function_0_0= ruleThread )
                    {
                    // InternalCplus.g:81:5: (lv_function_0_0= ruleThread )
                    // InternalCplus.g:82:6: lv_function_0_0= ruleThread
                    {

                    						newCompositeNode(grammarAccess.getCodeAccess().getFunctionThreadParserRuleCall_0_0_0());
                    					
                    pushFollow(FOLLOW_3);
                    lv_function_0_0=ruleThread();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCodeRule());
                    						}
                    						add(
                    							current,
                    							"function",
                    							lv_function_0_0,
                    							"ovanes.cplusdsl.Cplus.Thread");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:99:4: ( (lv_function_1_0= ruleThread ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==59||LA1_0==62) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalCplus.g:100:5: (lv_function_1_0= ruleThread )
                    	    {
                    	    // InternalCplus.g:100:5: (lv_function_1_0= ruleThread )
                    	    // InternalCplus.g:101:6: lv_function_1_0= ruleThread
                    	    {

                    	    						newCompositeNode(grammarAccess.getCodeAccess().getFunctionThreadParserRuleCall_0_1_0());
                    	    					
                    	    pushFollow(FOLLOW_3);
                    	    lv_function_1_0=ruleThread();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getCodeRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"function",
                    	    							lv_function_1_0,
                    	    							"ovanes.cplusdsl.Cplus.Thread");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalCplus.g:119:3: ( (lv_has_2_0= ruleInitiation ) )
            // InternalCplus.g:120:4: (lv_has_2_0= ruleInitiation )
            {
            // InternalCplus.g:120:4: (lv_has_2_0= ruleInitiation )
            // InternalCplus.g:121:5: lv_has_2_0= ruleInitiation
            {

            					newCompositeNode(grammarAccess.getCodeAccess().getHasInitiationParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_has_2_0=ruleInitiation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCodeRule());
            					}
            					set(
            						current,
            						"has",
            						lv_has_2_0,
            						"ovanes.cplusdsl.Cplus.Initiation");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCode"


    // $ANTLR start "entryRuleThread"
    // InternalCplus.g:142:1: entryRuleThread returns [EObject current=null] : iv_ruleThread= ruleThread EOF ;
    public final EObject entryRuleThread() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThread = null;


        try {
            // InternalCplus.g:142:47: (iv_ruleThread= ruleThread EOF )
            // InternalCplus.g:143:2: iv_ruleThread= ruleThread EOF
            {
             newCompositeNode(grammarAccess.getThreadRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThread=ruleThread();

            state._fsp--;

             current =iv_ruleThread; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThread"


    // $ANTLR start "ruleThread"
    // InternalCplus.g:149:1: ruleThread returns [EObject current=null] : (this_Function_0= ruleFunction | this_Method_1= ruleMethod ) ;
    public final EObject ruleThread() throws RecognitionException {
        EObject current = null;

        EObject this_Function_0 = null;

        EObject this_Method_1 = null;



        	enterRule();

        try {
            // InternalCplus.g:155:2: ( (this_Function_0= ruleFunction | this_Method_1= ruleMethod ) )
            // InternalCplus.g:156:2: (this_Function_0= ruleFunction | this_Method_1= ruleMethod )
            {
            // InternalCplus.g:156:2: (this_Function_0= ruleFunction | this_Method_1= ruleMethod )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==59) ) {
                alt3=1;
            }
            else if ( (LA3_0==62) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalCplus.g:157:3: this_Function_0= ruleFunction
                    {

                    			newCompositeNode(grammarAccess.getThreadAccess().getFunctionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Function_0=ruleFunction();

                    state._fsp--;


                    			current = this_Function_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:166:3: this_Method_1= ruleMethod
                    {

                    			newCompositeNode(grammarAccess.getThreadAccess().getMethodParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Method_1=ruleMethod();

                    state._fsp--;


                    			current = this_Method_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThread"


    // $ANTLR start "entryRuleStatements"
    // InternalCplus.g:178:1: entryRuleStatements returns [EObject current=null] : iv_ruleStatements= ruleStatements EOF ;
    public final EObject entryRuleStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatements = null;


        try {
            // InternalCplus.g:178:51: (iv_ruleStatements= ruleStatements EOF )
            // InternalCplus.g:179:2: iv_ruleStatements= ruleStatements EOF
            {
             newCompositeNode(grammarAccess.getStatementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStatements=ruleStatements();

            state._fsp--;

             current =iv_ruleStatements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatements"


    // $ANTLR start "ruleStatements"
    // InternalCplus.g:185:1: ruleStatements returns [EObject current=null] : (this_DeclarationVariable_0= ruleDeclarationVariable | this_CallFunction_1= ruleCallFunction | this_Assignment_2= ruleAssignment | this_Write_3= ruleWrite | this_Read_4= ruleRead | this_If_5= ruleIf | this_While_6= ruleWhile | this_Repeat_7= ruleRepeat | this_From_8= ruleFrom | this_Increment_9= ruleIncrement ) ;
    public final EObject ruleStatements() throws RecognitionException {
        EObject current = null;

        EObject this_DeclarationVariable_0 = null;

        EObject this_CallFunction_1 = null;

        EObject this_Assignment_2 = null;

        EObject this_Write_3 = null;

        EObject this_Read_4 = null;

        EObject this_If_5 = null;

        EObject this_While_6 = null;

        EObject this_Repeat_7 = null;

        EObject this_From_8 = null;

        EObject this_Increment_9 = null;



        	enterRule();

        try {
            // InternalCplus.g:191:2: ( (this_DeclarationVariable_0= ruleDeclarationVariable | this_CallFunction_1= ruleCallFunction | this_Assignment_2= ruleAssignment | this_Write_3= ruleWrite | this_Read_4= ruleRead | this_If_5= ruleIf | this_While_6= ruleWhile | this_Repeat_7= ruleRepeat | this_From_8= ruleFrom | this_Increment_9= ruleIncrement ) )
            // InternalCplus.g:192:2: (this_DeclarationVariable_0= ruleDeclarationVariable | this_CallFunction_1= ruleCallFunction | this_Assignment_2= ruleAssignment | this_Write_3= ruleWrite | this_Read_4= ruleRead | this_If_5= ruleIf | this_While_6= ruleWhile | this_Repeat_7= ruleRepeat | this_From_8= ruleFrom | this_Increment_9= ruleIncrement )
            {
            // InternalCplus.g:192:2: (this_DeclarationVariable_0= ruleDeclarationVariable | this_CallFunction_1= ruleCallFunction | this_Assignment_2= ruleAssignment | this_Write_3= ruleWrite | this_Read_4= ruleRead | this_If_5= ruleIf | this_While_6= ruleWhile | this_Repeat_7= ruleRepeat | this_From_8= ruleFrom | this_Increment_9= ruleIncrement )
            int alt4=10;
            alt4 = dfa4.predict(input);
            switch (alt4) {
                case 1 :
                    // InternalCplus.g:193:3: this_DeclarationVariable_0= ruleDeclarationVariable
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getDeclarationVariableParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_DeclarationVariable_0=ruleDeclarationVariable();

                    state._fsp--;


                    			current = this_DeclarationVariable_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:202:3: this_CallFunction_1= ruleCallFunction
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getCallFunctionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_CallFunction_1=ruleCallFunction();

                    state._fsp--;


                    			current = this_CallFunction_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCplus.g:211:3: this_Assignment_2= ruleAssignment
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getAssignmentParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Assignment_2=ruleAssignment();

                    state._fsp--;


                    			current = this_Assignment_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalCplus.g:220:3: this_Write_3= ruleWrite
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getWriteParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Write_3=ruleWrite();

                    state._fsp--;


                    			current = this_Write_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalCplus.g:229:3: this_Read_4= ruleRead
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getReadParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_Read_4=ruleRead();

                    state._fsp--;


                    			current = this_Read_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalCplus.g:238:3: this_If_5= ruleIf
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getIfParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_If_5=ruleIf();

                    state._fsp--;


                    			current = this_If_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalCplus.g:247:3: this_While_6= ruleWhile
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getWhileParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_While_6=ruleWhile();

                    state._fsp--;


                    			current = this_While_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalCplus.g:256:3: this_Repeat_7= ruleRepeat
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getRepeatParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_Repeat_7=ruleRepeat();

                    state._fsp--;


                    			current = this_Repeat_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 9 :
                    // InternalCplus.g:265:3: this_From_8= ruleFrom
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getFromParserRuleCall_8());
                    		
                    pushFollow(FOLLOW_2);
                    this_From_8=ruleFrom();

                    state._fsp--;


                    			current = this_From_8;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 10 :
                    // InternalCplus.g:274:3: this_Increment_9= ruleIncrement
                    {

                    			newCompositeNode(grammarAccess.getStatementsAccess().getIncrementParserRuleCall_9());
                    		
                    pushFollow(FOLLOW_2);
                    this_Increment_9=ruleIncrement();

                    state._fsp--;


                    			current = this_Increment_9;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatements"


    // $ANTLR start "entryRuleOperator"
    // InternalCplus.g:286:1: entryRuleOperator returns [EObject current=null] : iv_ruleOperator= ruleOperator EOF ;
    public final EObject entryRuleOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperator = null;


        try {
            // InternalCplus.g:286:49: (iv_ruleOperator= ruleOperator EOF )
            // InternalCplus.g:287:2: iv_ruleOperator= ruleOperator EOF
            {
             newCompositeNode(grammarAccess.getOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOperator=ruleOperator();

            state._fsp--;

             current =iv_ruleOperator; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperator"


    // $ANTLR start "ruleOperator"
    // InternalCplus.g:293:1: ruleOperator returns [EObject current=null] : (this_VariableID_0= ruleVariableID | this_ConstString_1= ruleConstString | this_Character_2= ruleCharacter | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_ValBoolean_5= ruleValBoolean ) ;
    public final EObject ruleOperator() throws RecognitionException {
        EObject current = null;

        EObject this_VariableID_0 = null;

        EObject this_ConstString_1 = null;

        EObject this_Character_2 = null;

        EObject this_Integer_3 = null;

        EObject this_IntDecimal_4 = null;

        EObject this_ValBoolean_5 = null;



        	enterRule();

        try {
            // InternalCplus.g:299:2: ( (this_VariableID_0= ruleVariableID | this_ConstString_1= ruleConstString | this_Character_2= ruleCharacter | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_ValBoolean_5= ruleValBoolean ) )
            // InternalCplus.g:300:2: (this_VariableID_0= ruleVariableID | this_ConstString_1= ruleConstString | this_Character_2= ruleCharacter | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_ValBoolean_5= ruleValBoolean )
            {
            // InternalCplus.g:300:2: (this_VariableID_0= ruleVariableID | this_ConstString_1= ruleConstString | this_Character_2= ruleCharacter | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_ValBoolean_5= ruleValBoolean )
            int alt5=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
            case RULE_ID:
                {
                alt5=1;
                }
                break;
            case RULE_CAD:
                {
                alt5=2;
                }
                break;
            case RULE_CAR:
                {
                alt5=3;
                }
                break;
            case 39:
                {
                int LA5_4 = input.LA(2);

                if ( (LA5_4==RULE_INT) ) {
                    int LA5_5 = input.LA(3);

                    if ( (LA5_5==40) ) {
                        alt5=5;
                    }
                    else if ( (LA5_5==EOF||LA5_5==16||LA5_5==18) ) {
                        alt5=4;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 5, input);

                        throw nvae;
                    }
                }
                else if ( (LA5_4==40) ) {
                    alt5=5;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 4, input);

                    throw nvae;
                }
                }
                break;
            case RULE_INT:
                {
                int LA5_5 = input.LA(2);

                if ( (LA5_5==40) ) {
                    alt5=5;
                }
                else if ( (LA5_5==EOF||LA5_5==16||LA5_5==18) ) {
                    alt5=4;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 5, input);

                    throw nvae;
                }
                }
                break;
            case 40:
                {
                alt5=5;
                }
                break;
            case 43:
            case 44:
                {
                alt5=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalCplus.g:301:3: this_VariableID_0= ruleVariableID
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getVariableIDParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_VariableID_0=ruleVariableID();

                    state._fsp--;


                    			current = this_VariableID_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:310:3: this_ConstString_1= ruleConstString
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getConstStringParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ConstString_1=ruleConstString();

                    state._fsp--;


                    			current = this_ConstString_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCplus.g:319:3: this_Character_2= ruleCharacter
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getCharacterParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Character_2=ruleCharacter();

                    state._fsp--;


                    			current = this_Character_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalCplus.g:328:3: this_Integer_3= ruleInteger
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getIntegerParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Integer_3=ruleInteger();

                    state._fsp--;


                    			current = this_Integer_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalCplus.g:337:3: this_IntDecimal_4= ruleIntDecimal
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getIntDecimalParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_IntDecimal_4=ruleIntDecimal();

                    state._fsp--;


                    			current = this_IntDecimal_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalCplus.g:346:3: this_ValBoolean_5= ruleValBoolean
                    {

                    			newCompositeNode(grammarAccess.getOperatorAccess().getValBooleanParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValBoolean_5=ruleValBoolean();

                    state._fsp--;


                    			current = this_ValBoolean_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperator"


    // $ANTLR start "entryRuleCharacter"
    // InternalCplus.g:358:1: entryRuleCharacter returns [EObject current=null] : iv_ruleCharacter= ruleCharacter EOF ;
    public final EObject entryRuleCharacter() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCharacter = null;


        try {
            // InternalCplus.g:358:50: (iv_ruleCharacter= ruleCharacter EOF )
            // InternalCplus.g:359:2: iv_ruleCharacter= ruleCharacter EOF
            {
             newCompositeNode(grammarAccess.getCharacterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCharacter=ruleCharacter();

            state._fsp--;

             current =iv_ruleCharacter; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCharacter"


    // $ANTLR start "ruleCharacter"
    // InternalCplus.g:365:1: ruleCharacter returns [EObject current=null] : ( (lv_content_0_0= RULE_CAR ) ) ;
    public final EObject ruleCharacter() throws RecognitionException {
        EObject current = null;

        Token lv_content_0_0=null;


        	enterRule();

        try {
            // InternalCplus.g:371:2: ( ( (lv_content_0_0= RULE_CAR ) ) )
            // InternalCplus.g:372:2: ( (lv_content_0_0= RULE_CAR ) )
            {
            // InternalCplus.g:372:2: ( (lv_content_0_0= RULE_CAR ) )
            // InternalCplus.g:373:3: (lv_content_0_0= RULE_CAR )
            {
            // InternalCplus.g:373:3: (lv_content_0_0= RULE_CAR )
            // InternalCplus.g:374:4: lv_content_0_0= RULE_CAR
            {
            lv_content_0_0=(Token)match(input,RULE_CAR,FOLLOW_2); 

            				newLeafNode(lv_content_0_0, grammarAccess.getCharacterAccess().getContentCARTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getCharacterRule());
            				}
            				setWithLastConsumed(
            					current,
            					"content",
            					lv_content_0_0,
            					"ovanes.cplusdsl.Cplus.CAR");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCharacter"


    // $ANTLR start "entryRulevalue"
    // InternalCplus.g:393:1: entryRulevalue returns [EObject current=null] : iv_rulevalue= rulevalue EOF ;
    public final EObject entryRulevalue() throws RecognitionException {
        EObject current = null;

        EObject iv_rulevalue = null;


        try {
            // InternalCplus.g:393:46: (iv_rulevalue= rulevalue EOF )
            // InternalCplus.g:394:2: iv_rulevalue= rulevalue EOF
            {
             newCompositeNode(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_1);
            iv_rulevalue=rulevalue();

            state._fsp--;

             current =iv_rulevalue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulevalue"


    // $ANTLR start "rulevalue"
    // InternalCplus.g:400:1: rulevalue returns [EObject current=null] : (this_CallFunction_0= ruleCallFunction | this_VariableID_1= ruleVariableID | this_ConstString_2= ruleConstString | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_operation_5= ruleoperation | this_ValBoolean_6= ruleValBoolean | this_Character_7= ruleCharacter ) ;
    public final EObject rulevalue() throws RecognitionException {
        EObject current = null;

        EObject this_CallFunction_0 = null;

        EObject this_VariableID_1 = null;

        EObject this_ConstString_2 = null;

        EObject this_Integer_3 = null;

        EObject this_IntDecimal_4 = null;

        EObject this_operation_5 = null;

        EObject this_ValBoolean_6 = null;

        EObject this_Character_7 = null;



        	enterRule();

        try {
            // InternalCplus.g:406:2: ( (this_CallFunction_0= ruleCallFunction | this_VariableID_1= ruleVariableID | this_ConstString_2= ruleConstString | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_operation_5= ruleoperation | this_ValBoolean_6= ruleValBoolean | this_Character_7= ruleCharacter ) )
            // InternalCplus.g:407:2: (this_CallFunction_0= ruleCallFunction | this_VariableID_1= ruleVariableID | this_ConstString_2= ruleConstString | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_operation_5= ruleoperation | this_ValBoolean_6= ruleValBoolean | this_Character_7= ruleCharacter )
            {
            // InternalCplus.g:407:2: (this_CallFunction_0= ruleCallFunction | this_VariableID_1= ruleVariableID | this_ConstString_2= ruleConstString | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_operation_5= ruleoperation | this_ValBoolean_6= ruleValBoolean | this_Character_7= ruleCharacter )
            int alt6=8;
            alt6 = dfa6.predict(input);
            switch (alt6) {
                case 1 :
                    // InternalCplus.g:408:3: this_CallFunction_0= ruleCallFunction
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getCallFunctionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CallFunction_0=ruleCallFunction();

                    state._fsp--;


                    			current = this_CallFunction_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:417:3: this_VariableID_1= ruleVariableID
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getVariableIDParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_VariableID_1=ruleVariableID();

                    state._fsp--;


                    			current = this_VariableID_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalCplus.g:426:3: this_ConstString_2= ruleConstString
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getConstStringParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ConstString_2=ruleConstString();

                    state._fsp--;


                    			current = this_ConstString_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalCplus.g:435:3: this_Integer_3= ruleInteger
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getIntegerParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Integer_3=ruleInteger();

                    state._fsp--;


                    			current = this_Integer_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalCplus.g:444:3: this_IntDecimal_4= ruleIntDecimal
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getIntDecimalParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_IntDecimal_4=ruleIntDecimal();

                    state._fsp--;


                    			current = this_IntDecimal_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalCplus.g:453:3: this_operation_5= ruleoperation
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getOperationParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_operation_5=ruleoperation();

                    state._fsp--;


                    			current = this_operation_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalCplus.g:462:3: this_ValBoolean_6= ruleValBoolean
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getValBooleanParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValBoolean_6=ruleValBoolean();

                    state._fsp--;


                    			current = this_ValBoolean_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalCplus.g:471:3: this_Character_7= ruleCharacter
                    {

                    			newCompositeNode(grammarAccess.getValueAccess().getCharacterParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_Character_7=ruleCharacter();

                    state._fsp--;


                    			current = this_Character_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulevalue"


    // $ANTLR start "entryRuleInitiation"
    // InternalCplus.g:483:1: entryRuleInitiation returns [EObject current=null] : iv_ruleInitiation= ruleInitiation EOF ;
    public final EObject entryRuleInitiation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInitiation = null;


        try {
            // InternalCplus.g:483:51: (iv_ruleInitiation= ruleInitiation EOF )
            // InternalCplus.g:484:2: iv_ruleInitiation= ruleInitiation EOF
            {
             newCompositeNode(grammarAccess.getInitiationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInitiation=ruleInitiation();

            state._fsp--;

             current =iv_ruleInitiation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInitiation"


    // $ANTLR start "ruleInitiation"
    // InternalCplus.g:490:1: ruleInitiation returns [EObject current=null] : ( () otherlv_1= 'initiation' ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )? otherlv_4= 'endinitiation' ) ;
    public final EObject ruleInitiation() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_4=null;
        EObject lv_has_2_0 = null;

        EObject lv_has_3_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:496:2: ( ( () otherlv_1= 'initiation' ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )? otherlv_4= 'endinitiation' ) )
            // InternalCplus.g:497:2: ( () otherlv_1= 'initiation' ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )? otherlv_4= 'endinitiation' )
            {
            // InternalCplus.g:497:2: ( () otherlv_1= 'initiation' ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )? otherlv_4= 'endinitiation' )
            // InternalCplus.g:498:3: () otherlv_1= 'initiation' ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )? otherlv_4= 'endinitiation'
            {
            // InternalCplus.g:498:3: ()
            // InternalCplus.g:499:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInitiationAccess().getInitiationAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getInitiationAccess().getInitiationKeyword_1());
            		
            // InternalCplus.g:509:3: ( ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )* )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( ((LA8_0>=RULE_STRING && LA8_0<=RULE_ID)||(LA8_0>=20 && LA8_0<=22)||(LA8_0>=25 && LA8_0<=26)||LA8_0==30||(LA8_0>=34 && LA8_0<=38)) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalCplus.g:510:4: ( (lv_has_2_0= ruleStatements ) ) ( (lv_has_3_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:510:4: ( (lv_has_2_0= ruleStatements ) )
                    // InternalCplus.g:511:5: (lv_has_2_0= ruleStatements )
                    {
                    // InternalCplus.g:511:5: (lv_has_2_0= ruleStatements )
                    // InternalCplus.g:512:6: lv_has_2_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getInitiationAccess().getHasStatementsParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_4);
                    lv_has_2_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getInitiationRule());
                    						}
                    						add(
                    							current,
                    							"has",
                    							lv_has_2_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:529:4: ( (lv_has_3_0= ruleStatements ) )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( ((LA7_0>=RULE_STRING && LA7_0<=RULE_ID)||(LA7_0>=20 && LA7_0<=22)||(LA7_0>=25 && LA7_0<=26)||LA7_0==30||(LA7_0>=34 && LA7_0<=38)) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // InternalCplus.g:530:5: (lv_has_3_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:530:5: (lv_has_3_0= ruleStatements )
                    	    // InternalCplus.g:531:6: lv_has_3_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getInitiationAccess().getHasStatementsParserRuleCall_2_1_0());
                    	    					
                    	    pushFollow(FOLLOW_4);
                    	    lv_has_3_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getInitiationRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"has",
                    	    							lv_has_3_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getInitiationAccess().getEndinitiationKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInitiation"


    // $ANTLR start "entryRuleEString"
    // InternalCplus.g:557:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalCplus.g:557:47: (iv_ruleEString= ruleEString EOF )
            // InternalCplus.g:558:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalCplus.g:564:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalCplus.g:570:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalCplus.g:571:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalCplus.g:571:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_STRING) ) {
                alt9=1;
            }
            else if ( (LA9_0==RULE_ID) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalCplus.g:572:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:580:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleDeclarationVariable"
    // InternalCplus.g:591:1: entryRuleDeclarationVariable returns [EObject current=null] : iv_ruleDeclarationVariable= ruleDeclarationVariable EOF ;
    public final EObject entryRuleDeclarationVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDeclarationVariable = null;


        try {
            // InternalCplus.g:591:60: (iv_ruleDeclarationVariable= ruleDeclarationVariable EOF )
            // InternalCplus.g:592:2: iv_ruleDeclarationVariable= ruleDeclarationVariable EOF
            {
             newCompositeNode(grammarAccess.getDeclarationVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeclarationVariable=ruleDeclarationVariable();

            state._fsp--;

             current =iv_ruleDeclarationVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeclarationVariable"


    // $ANTLR start "ruleDeclarationVariable"
    // InternalCplus.g:598:1: ruleDeclarationVariable returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_containsIDs_1_0= ruleVariable ) ) (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )* ) ;
    public final EObject ruleDeclarationVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject lv_type_0_0 = null;

        EObject lv_containsIDs_1_0 = null;

        EObject lv_containsIDs_3_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:604:2: ( ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_containsIDs_1_0= ruleVariable ) ) (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )* ) )
            // InternalCplus.g:605:2: ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_containsIDs_1_0= ruleVariable ) ) (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )* )
            {
            // InternalCplus.g:605:2: ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_containsIDs_1_0= ruleVariable ) ) (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )* )
            // InternalCplus.g:606:3: ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_containsIDs_1_0= ruleVariable ) ) (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )*
            {
            // InternalCplus.g:606:3: ( (lv_type_0_0= ruleTypeVariable ) )
            // InternalCplus.g:607:4: (lv_type_0_0= ruleTypeVariable )
            {
            // InternalCplus.g:607:4: (lv_type_0_0= ruleTypeVariable )
            // InternalCplus.g:608:5: lv_type_0_0= ruleTypeVariable
            {

            					newCompositeNode(grammarAccess.getDeclarationVariableAccess().getTypeTypeVariableParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_5);
            lv_type_0_0=ruleTypeVariable();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDeclarationVariableRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"ovanes.cplusdsl.Cplus.TypeVariable");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:625:3: ( (lv_containsIDs_1_0= ruleVariable ) )
            // InternalCplus.g:626:4: (lv_containsIDs_1_0= ruleVariable )
            {
            // InternalCplus.g:626:4: (lv_containsIDs_1_0= ruleVariable )
            // InternalCplus.g:627:5: lv_containsIDs_1_0= ruleVariable
            {

            					newCompositeNode(grammarAccess.getDeclarationVariableAccess().getContainsIDsVariableParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_containsIDs_1_0=ruleVariable();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDeclarationVariableRule());
            					}
            					add(
            						current,
            						"containsIDs",
            						lv_containsIDs_1_0,
            						"ovanes.cplusdsl.Cplus.Variable");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:644:3: (otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==16) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalCplus.g:645:4: otherlv_2= ',' ( (lv_containsIDs_3_0= ruleVariable ) )
            	    {
            	    otherlv_2=(Token)match(input,16,FOLLOW_5); 

            	    				newLeafNode(otherlv_2, grammarAccess.getDeclarationVariableAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalCplus.g:649:4: ( (lv_containsIDs_3_0= ruleVariable ) )
            	    // InternalCplus.g:650:5: (lv_containsIDs_3_0= ruleVariable )
            	    {
            	    // InternalCplus.g:650:5: (lv_containsIDs_3_0= ruleVariable )
            	    // InternalCplus.g:651:6: lv_containsIDs_3_0= ruleVariable
            	    {

            	    						newCompositeNode(grammarAccess.getDeclarationVariableAccess().getContainsIDsVariableParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_6);
            	    lv_containsIDs_3_0=ruleVariable();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getDeclarationVariableRule());
            	    						}
            	    						add(
            	    							current,
            	    							"containsIDs",
            	    							lv_containsIDs_3_0,
            	    							"ovanes.cplusdsl.Cplus.Variable");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeclarationVariable"


    // $ANTLR start "entryRuleCallFunction"
    // InternalCplus.g:673:1: entryRuleCallFunction returns [EObject current=null] : iv_ruleCallFunction= ruleCallFunction EOF ;
    public final EObject entryRuleCallFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCallFunction = null;


        try {
            // InternalCplus.g:673:53: (iv_ruleCallFunction= ruleCallFunction EOF )
            // InternalCplus.g:674:2: iv_ruleCallFunction= ruleCallFunction EOF
            {
             newCompositeNode(grammarAccess.getCallFunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCallFunction=ruleCallFunction();

            state._fsp--;

             current =iv_ruleCallFunction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCallFunction"


    // $ANTLR start "ruleCallFunction"
    // InternalCplus.g:680:1: ruleCallFunction returns [EObject current=null] : ( ( (lv_name_0_0= ruleEString ) ) otherlv_1= '(' ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )? otherlv_5= ')' ) ;
    public final EObject ruleCallFunction() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_0_0 = null;

        EObject lv_operator_2_0 = null;

        EObject lv_operator_4_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:686:2: ( ( ( (lv_name_0_0= ruleEString ) ) otherlv_1= '(' ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )? otherlv_5= ')' ) )
            // InternalCplus.g:687:2: ( ( (lv_name_0_0= ruleEString ) ) otherlv_1= '(' ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )? otherlv_5= ')' )
            {
            // InternalCplus.g:687:2: ( ( (lv_name_0_0= ruleEString ) ) otherlv_1= '(' ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )? otherlv_5= ')' )
            // InternalCplus.g:688:3: ( (lv_name_0_0= ruleEString ) ) otherlv_1= '(' ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )? otherlv_5= ')'
            {
            // InternalCplus.g:688:3: ( (lv_name_0_0= ruleEString ) )
            // InternalCplus.g:689:4: (lv_name_0_0= ruleEString )
            {
            // InternalCplus.g:689:4: (lv_name_0_0= ruleEString )
            // InternalCplus.g:690:5: lv_name_0_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getCallFunctionAccess().getNameEStringParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_7);
            lv_name_0_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCallFunctionRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_0_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_1=(Token)match(input,17,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getCallFunctionAccess().getLeftParenthesisKeyword_1());
            		
            // InternalCplus.g:711:3: ( ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=RULE_CAR && LA12_0<=RULE_ID)||(LA12_0>=RULE_CAD && LA12_0<=RULE_INT)||(LA12_0>=39 && LA12_0<=40)||(LA12_0>=43 && LA12_0<=44)) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalCplus.g:712:4: ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )*
                    {
                    // InternalCplus.g:712:4: ( (lv_operator_2_0= ruleOperator ) )
                    // InternalCplus.g:713:5: (lv_operator_2_0= ruleOperator )
                    {
                    // InternalCplus.g:713:5: (lv_operator_2_0= ruleOperator )
                    // InternalCplus.g:714:6: lv_operator_2_0= ruleOperator
                    {

                    						newCompositeNode(grammarAccess.getCallFunctionAccess().getOperatorOperatorParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_operator_2_0=ruleOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCallFunctionRule());
                    						}
                    						add(
                    							current,
                    							"operator",
                    							lv_operator_2_0,
                    							"ovanes.cplusdsl.Cplus.Operator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:731:4: (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )*
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( (LA11_0==16) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // InternalCplus.g:732:5: otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) )
                    	    {
                    	    otherlv_3=(Token)match(input,16,FOLLOW_10); 

                    	    					newLeafNode(otherlv_3, grammarAccess.getCallFunctionAccess().getCommaKeyword_2_1_0());
                    	    				
                    	    // InternalCplus.g:736:5: ( (lv_operator_4_0= ruleOperator ) )
                    	    // InternalCplus.g:737:6: (lv_operator_4_0= ruleOperator )
                    	    {
                    	    // InternalCplus.g:737:6: (lv_operator_4_0= ruleOperator )
                    	    // InternalCplus.g:738:7: lv_operator_4_0= ruleOperator
                    	    {

                    	    							newCompositeNode(grammarAccess.getCallFunctionAccess().getOperatorOperatorParserRuleCall_2_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_operator_4_0=ruleOperator();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCallFunctionRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"operator",
                    	    								lv_operator_4_0,
                    	    								"ovanes.cplusdsl.Cplus.Operator");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop11;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getCallFunctionAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCallFunction"


    // $ANTLR start "entryRuleAssignment"
    // InternalCplus.g:765:1: entryRuleAssignment returns [EObject current=null] : iv_ruleAssignment= ruleAssignment EOF ;
    public final EObject entryRuleAssignment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAssignment = null;


        try {
            // InternalCplus.g:765:51: (iv_ruleAssignment= ruleAssignment EOF )
            // InternalCplus.g:766:2: iv_ruleAssignment= ruleAssignment EOF
            {
             newCompositeNode(grammarAccess.getAssignmentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAssignment=ruleAssignment();

            state._fsp--;

             current =iv_ruleAssignment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAssignment"


    // $ANTLR start "ruleAssignment"
    // InternalCplus.g:772:1: ruleAssignment returns [EObject current=null] : ( ( (lv_lvalue_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* otherlv_2= '=' ( (lv_operator_3_0= rulevalue ) ) ) ;
    public final EObject ruleAssignment() throws RecognitionException {
        EObject current = null;

        Token lv_Mat_1_0=null;
        Token otherlv_2=null;
        AntlrDatatypeRuleToken lv_lvalue_0_0 = null;

        EObject lv_operator_3_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:778:2: ( ( ( (lv_lvalue_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* otherlv_2= '=' ( (lv_operator_3_0= rulevalue ) ) ) )
            // InternalCplus.g:779:2: ( ( (lv_lvalue_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* otherlv_2= '=' ( (lv_operator_3_0= rulevalue ) ) )
            {
            // InternalCplus.g:779:2: ( ( (lv_lvalue_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* otherlv_2= '=' ( (lv_operator_3_0= rulevalue ) ) )
            // InternalCplus.g:780:3: ( (lv_lvalue_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* otherlv_2= '=' ( (lv_operator_3_0= rulevalue ) )
            {
            // InternalCplus.g:780:3: ( (lv_lvalue_0_0= ruleEString ) )
            // InternalCplus.g:781:4: (lv_lvalue_0_0= ruleEString )
            {
            // InternalCplus.g:781:4: (lv_lvalue_0_0= ruleEString )
            // InternalCplus.g:782:5: lv_lvalue_0_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAssignmentAccess().getLvalueEStringParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_11);
            lv_lvalue_0_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentRule());
            					}
            					set(
            						current,
            						"lvalue",
            						lv_lvalue_0_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:799:3: ( (lv_Mat_1_0= RULE_MATRIX ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==RULE_MATRIX) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalCplus.g:800:4: (lv_Mat_1_0= RULE_MATRIX )
            	    {
            	    // InternalCplus.g:800:4: (lv_Mat_1_0= RULE_MATRIX )
            	    // InternalCplus.g:801:5: lv_Mat_1_0= RULE_MATRIX
            	    {
            	    lv_Mat_1_0=(Token)match(input,RULE_MATRIX,FOLLOW_11); 

            	    					newLeafNode(lv_Mat_1_0, grammarAccess.getAssignmentAccess().getMatMATRIXTerminalRuleCall_1_0());
            	    				

            	    					if (current==null) {
            	    						current = createModelElement(grammarAccess.getAssignmentRule());
            	    					}
            	    					addWithLastConsumed(
            	    						current,
            	    						"Mat",
            	    						lv_Mat_1_0,
            	    						"ovanes.cplusdsl.Cplus.MATRIX");
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            otherlv_2=(Token)match(input,19,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getAssignmentAccess().getEqualsSignKeyword_2());
            		
            // InternalCplus.g:821:3: ( (lv_operator_3_0= rulevalue ) )
            // InternalCplus.g:822:4: (lv_operator_3_0= rulevalue )
            {
            // InternalCplus.g:822:4: (lv_operator_3_0= rulevalue )
            // InternalCplus.g:823:5: lv_operator_3_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getAssignmentAccess().getOperatorValueParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_operator_3_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAssignment"


    // $ANTLR start "entryRuleWrite"
    // InternalCplus.g:844:1: entryRuleWrite returns [EObject current=null] : iv_ruleWrite= ruleWrite EOF ;
    public final EObject entryRuleWrite() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWrite = null;


        try {
            // InternalCplus.g:844:46: (iv_ruleWrite= ruleWrite EOF )
            // InternalCplus.g:845:2: iv_ruleWrite= ruleWrite EOF
            {
             newCompositeNode(grammarAccess.getWriteRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWrite=ruleWrite();

            state._fsp--;

             current =iv_ruleWrite; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWrite"


    // $ANTLR start "ruleWrite"
    // InternalCplus.g:851:1: ruleWrite returns [EObject current=null] : (otherlv_0= 'write' otherlv_1= '(' ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* otherlv_5= ')' ) ;
    public final EObject ruleWrite() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_operator_2_0 = null;

        EObject lv_operator_4_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:857:2: ( (otherlv_0= 'write' otherlv_1= '(' ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* otherlv_5= ')' ) )
            // InternalCplus.g:858:2: (otherlv_0= 'write' otherlv_1= '(' ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* otherlv_5= ')' )
            {
            // InternalCplus.g:858:2: (otherlv_0= 'write' otherlv_1= '(' ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* otherlv_5= ')' )
            // InternalCplus.g:859:3: otherlv_0= 'write' otherlv_1= '(' ( (lv_operator_2_0= ruleOperator ) ) (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )* otherlv_5= ')'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getWriteAccess().getWriteKeyword_0());
            		
            otherlv_1=(Token)match(input,17,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getWriteAccess().getLeftParenthesisKeyword_1());
            		
            // InternalCplus.g:867:3: ( (lv_operator_2_0= ruleOperator ) )
            // InternalCplus.g:868:4: (lv_operator_2_0= ruleOperator )
            {
            // InternalCplus.g:868:4: (lv_operator_2_0= ruleOperator )
            // InternalCplus.g:869:5: lv_operator_2_0= ruleOperator
            {

            					newCompositeNode(grammarAccess.getWriteAccess().getOperatorOperatorParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_9);
            lv_operator_2_0=ruleOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWriteRule());
            					}
            					add(
            						current,
            						"operator",
            						lv_operator_2_0,
            						"ovanes.cplusdsl.Cplus.Operator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:886:3: (otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==16) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalCplus.g:887:4: otherlv_3= ',' ( (lv_operator_4_0= ruleOperator ) )
            	    {
            	    otherlv_3=(Token)match(input,16,FOLLOW_10); 

            	    				newLeafNode(otherlv_3, grammarAccess.getWriteAccess().getCommaKeyword_3_0());
            	    			
            	    // InternalCplus.g:891:4: ( (lv_operator_4_0= ruleOperator ) )
            	    // InternalCplus.g:892:5: (lv_operator_4_0= ruleOperator )
            	    {
            	    // InternalCplus.g:892:5: (lv_operator_4_0= ruleOperator )
            	    // InternalCplus.g:893:6: lv_operator_4_0= ruleOperator
            	    {

            	    						newCompositeNode(grammarAccess.getWriteAccess().getOperatorOperatorParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_9);
            	    lv_operator_4_0=ruleOperator();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getWriteRule());
            	    						}
            	    						add(
            	    							current,
            	    							"operator",
            	    							lv_operator_4_0,
            	    							"ovanes.cplusdsl.Cplus.Operator");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getWriteAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWrite"


    // $ANTLR start "entryRuleRead"
    // InternalCplus.g:919:1: entryRuleRead returns [EObject current=null] : iv_ruleRead= ruleRead EOF ;
    public final EObject entryRuleRead() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRead = null;


        try {
            // InternalCplus.g:919:45: (iv_ruleRead= ruleRead EOF )
            // InternalCplus.g:920:2: iv_ruleRead= ruleRead EOF
            {
             newCompositeNode(grammarAccess.getReadRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRead=ruleRead();

            state._fsp--;

             current =iv_ruleRead; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRead"


    // $ANTLR start "ruleRead"
    // InternalCplus.g:926:1: ruleRead returns [EObject current=null] : (otherlv_0= 'read' otherlv_1= '(' ( (lv_variable_2_0= ruleVariableID ) ) otherlv_3= ')' ) ;
    public final EObject ruleRead() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_variable_2_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:932:2: ( (otherlv_0= 'read' otherlv_1= '(' ( (lv_variable_2_0= ruleVariableID ) ) otherlv_3= ')' ) )
            // InternalCplus.g:933:2: (otherlv_0= 'read' otherlv_1= '(' ( (lv_variable_2_0= ruleVariableID ) ) otherlv_3= ')' )
            {
            // InternalCplus.g:933:2: (otherlv_0= 'read' otherlv_1= '(' ( (lv_variable_2_0= ruleVariableID ) ) otherlv_3= ')' )
            // InternalCplus.g:934:3: otherlv_0= 'read' otherlv_1= '(' ( (lv_variable_2_0= ruleVariableID ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getReadAccess().getReadKeyword_0());
            		
            otherlv_1=(Token)match(input,17,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getReadAccess().getLeftParenthesisKeyword_1());
            		
            // InternalCplus.g:942:3: ( (lv_variable_2_0= ruleVariableID ) )
            // InternalCplus.g:943:4: (lv_variable_2_0= ruleVariableID )
            {
            // InternalCplus.g:943:4: (lv_variable_2_0= ruleVariableID )
            // InternalCplus.g:944:5: lv_variable_2_0= ruleVariableID
            {

            					newCompositeNode(grammarAccess.getReadAccess().getVariableVariableIDParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_13);
            lv_variable_2_0=ruleVariableID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReadRule());
            					}
            					set(
            						current,
            						"variable",
            						lv_variable_2_0,
            						"ovanes.cplusdsl.Cplus.VariableID");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getReadAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRead"


    // $ANTLR start "entryRuleIf"
    // InternalCplus.g:969:1: entryRuleIf returns [EObject current=null] : iv_ruleIf= ruleIf EOF ;
    public final EObject entryRuleIf() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIf = null;


        try {
            // InternalCplus.g:969:43: (iv_ruleIf= ruleIf EOF )
            // InternalCplus.g:970:2: iv_ruleIf= ruleIf EOF
            {
             newCompositeNode(grammarAccess.getIfRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIf=ruleIf();

            state._fsp--;

             current =iv_ruleIf; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIf"


    // $ANTLR start "ruleIf"
    // InternalCplus.g:976:1: ruleIf returns [EObject current=null] : (otherlv_0= 'if' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'then' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? ( (lv_elseif_5_0= ruleElseif ) )? otherlv_6= 'endif' ) ;
    public final EObject ruleIf() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_6=null;
        EObject lv_value_1_0 = null;

        EObject lv_statements_3_0 = null;

        EObject lv_statements_4_0 = null;

        EObject lv_elseif_5_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:982:2: ( (otherlv_0= 'if' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'then' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? ( (lv_elseif_5_0= ruleElseif ) )? otherlv_6= 'endif' ) )
            // InternalCplus.g:983:2: (otherlv_0= 'if' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'then' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? ( (lv_elseif_5_0= ruleElseif ) )? otherlv_6= 'endif' )
            {
            // InternalCplus.g:983:2: (otherlv_0= 'if' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'then' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? ( (lv_elseif_5_0= ruleElseif ) )? otherlv_6= 'endif' )
            // InternalCplus.g:984:3: otherlv_0= 'if' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'then' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? ( (lv_elseif_5_0= ruleElseif ) )? otherlv_6= 'endif'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getIfAccess().getIfKeyword_0());
            		
            // InternalCplus.g:988:3: ( (lv_value_1_0= rulevalue ) )
            // InternalCplus.g:989:4: (lv_value_1_0= rulevalue )
            {
            // InternalCplus.g:989:4: (lv_value_1_0= rulevalue )
            // InternalCplus.g:990:5: lv_value_1_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getIfAccess().getValueValueParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_14);
            lv_value_1_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_1_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_15); 

            			newLeafNode(otherlv_2, grammarAccess.getIfAccess().getThenKeyword_2());
            		
            // InternalCplus.g:1011:3: ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( ((LA16_0>=RULE_STRING && LA16_0<=RULE_ID)||(LA16_0>=20 && LA16_0<=22)||(LA16_0>=25 && LA16_0<=26)||LA16_0==30||(LA16_0>=34 && LA16_0<=38)) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalCplus.g:1012:4: ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:1012:4: ( (lv_statements_3_0= ruleStatements ) )
                    // InternalCplus.g:1013:5: (lv_statements_3_0= ruleStatements )
                    {
                    // InternalCplus.g:1013:5: (lv_statements_3_0= ruleStatements )
                    // InternalCplus.g:1014:6: lv_statements_3_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getIfAccess().getStatementsStatementsParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_statements_3_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIfRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_3_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:1031:4: ( (lv_statements_4_0= ruleStatements ) )*
                    loop15:
                    do {
                        int alt15=2;
                        int LA15_0 = input.LA(1);

                        if ( ((LA15_0>=RULE_STRING && LA15_0<=RULE_ID)||(LA15_0>=20 && LA15_0<=22)||(LA15_0>=25 && LA15_0<=26)||LA15_0==30||(LA15_0>=34 && LA15_0<=38)) ) {
                            alt15=1;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // InternalCplus.g:1032:5: (lv_statements_4_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:1032:5: (lv_statements_4_0= ruleStatements )
                    	    // InternalCplus.g:1033:6: lv_statements_4_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getIfAccess().getStatementsStatementsParserRuleCall_3_1_0());
                    	    					
                    	    pushFollow(FOLLOW_15);
                    	    lv_statements_4_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getIfRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_4_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop15;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalCplus.g:1051:3: ( (lv_elseif_5_0= ruleElseif ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==56) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalCplus.g:1052:4: (lv_elseif_5_0= ruleElseif )
                    {
                    // InternalCplus.g:1052:4: (lv_elseif_5_0= ruleElseif )
                    // InternalCplus.g:1053:5: lv_elseif_5_0= ruleElseif
                    {

                    					newCompositeNode(grammarAccess.getIfAccess().getElseifElseifParserRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_16);
                    lv_elseif_5_0=ruleElseif();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIfRule());
                    					}
                    					set(
                    						current,
                    						"elseif",
                    						lv_elseif_5_0,
                    						"ovanes.cplusdsl.Cplus.Elseif");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,24,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getIfAccess().getEndifKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIf"


    // $ANTLR start "entryRuleWhile"
    // InternalCplus.g:1078:1: entryRuleWhile returns [EObject current=null] : iv_ruleWhile= ruleWhile EOF ;
    public final EObject entryRuleWhile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhile = null;


        try {
            // InternalCplus.g:1078:46: (iv_ruleWhile= ruleWhile EOF )
            // InternalCplus.g:1079:2: iv_ruleWhile= ruleWhile EOF
            {
             newCompositeNode(grammarAccess.getWhileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWhile=ruleWhile();

            state._fsp--;

             current =iv_ruleWhile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhile"


    // $ANTLR start "ruleWhile"
    // InternalCplus.g:1085:1: ruleWhile returns [EObject current=null] : (otherlv_0= 'while' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'repeat' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? otherlv_5= 'endwhile' ) ;
    public final EObject ruleWhile() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_5=null;
        EObject lv_value_1_0 = null;

        EObject lv_statements_3_0 = null;

        EObject lv_statements_4_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1091:2: ( (otherlv_0= 'while' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'repeat' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? otherlv_5= 'endwhile' ) )
            // InternalCplus.g:1092:2: (otherlv_0= 'while' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'repeat' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? otherlv_5= 'endwhile' )
            {
            // InternalCplus.g:1092:2: (otherlv_0= 'while' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'repeat' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? otherlv_5= 'endwhile' )
            // InternalCplus.g:1093:3: otherlv_0= 'while' ( (lv_value_1_0= rulevalue ) ) otherlv_2= 'repeat' ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )? otherlv_5= 'endwhile'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getWhileAccess().getWhileKeyword_0());
            		
            // InternalCplus.g:1097:3: ( (lv_value_1_0= rulevalue ) )
            // InternalCplus.g:1098:4: (lv_value_1_0= rulevalue )
            {
            // InternalCplus.g:1098:4: (lv_value_1_0= rulevalue )
            // InternalCplus.g:1099:5: lv_value_1_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getWhileAccess().getValueValueParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_17);
            lv_value_1_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_1_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,26,FOLLOW_18); 

            			newLeafNode(otherlv_2, grammarAccess.getWhileAccess().getRepeatKeyword_2());
            		
            // InternalCplus.g:1120:3: ( ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )* )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( ((LA19_0>=RULE_STRING && LA19_0<=RULE_ID)||(LA19_0>=20 && LA19_0<=22)||(LA19_0>=25 && LA19_0<=26)||LA19_0==30||(LA19_0>=34 && LA19_0<=38)) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalCplus.g:1121:4: ( (lv_statements_3_0= ruleStatements ) ) ( (lv_statements_4_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:1121:4: ( (lv_statements_3_0= ruleStatements ) )
                    // InternalCplus.g:1122:5: (lv_statements_3_0= ruleStatements )
                    {
                    // InternalCplus.g:1122:5: (lv_statements_3_0= ruleStatements )
                    // InternalCplus.g:1123:6: lv_statements_3_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getWhileAccess().getStatementsStatementsParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_statements_3_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getWhileRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_3_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:1140:4: ( (lv_statements_4_0= ruleStatements ) )*
                    loop18:
                    do {
                        int alt18=2;
                        int LA18_0 = input.LA(1);

                        if ( ((LA18_0>=RULE_STRING && LA18_0<=RULE_ID)||(LA18_0>=20 && LA18_0<=22)||(LA18_0>=25 && LA18_0<=26)||LA18_0==30||(LA18_0>=34 && LA18_0<=38)) ) {
                            alt18=1;
                        }


                        switch (alt18) {
                    	case 1 :
                    	    // InternalCplus.g:1141:5: (lv_statements_4_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:1141:5: (lv_statements_4_0= ruleStatements )
                    	    // InternalCplus.g:1142:6: lv_statements_4_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getWhileAccess().getStatementsStatementsParserRuleCall_3_1_0());
                    	    					
                    	    pushFollow(FOLLOW_18);
                    	    lv_statements_4_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getWhileRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_4_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop18;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_5=(Token)match(input,27,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getWhileAccess().getEndwhileKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhile"


    // $ANTLR start "entryRuleRepeat"
    // InternalCplus.g:1168:1: entryRuleRepeat returns [EObject current=null] : iv_ruleRepeat= ruleRepeat EOF ;
    public final EObject entryRuleRepeat() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRepeat = null;


        try {
            // InternalCplus.g:1168:47: (iv_ruleRepeat= ruleRepeat EOF )
            // InternalCplus.g:1169:2: iv_ruleRepeat= ruleRepeat EOF
            {
             newCompositeNode(grammarAccess.getRepeatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRepeat=ruleRepeat();

            state._fsp--;

             current =iv_ruleRepeat; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRepeat"


    // $ANTLR start "ruleRepeat"
    // InternalCplus.g:1175:1: ruleRepeat returns [EObject current=null] : (otherlv_0= 'repeat' ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )? otherlv_3= 'when' ( (lv_value_4_0= rulevalue ) ) otherlv_5= 'endrepeat' ) ;
    public final EObject ruleRepeat() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_statements_1_0 = null;

        EObject lv_statements_2_0 = null;

        EObject lv_value_4_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1181:2: ( (otherlv_0= 'repeat' ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )? otherlv_3= 'when' ( (lv_value_4_0= rulevalue ) ) otherlv_5= 'endrepeat' ) )
            // InternalCplus.g:1182:2: (otherlv_0= 'repeat' ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )? otherlv_3= 'when' ( (lv_value_4_0= rulevalue ) ) otherlv_5= 'endrepeat' )
            {
            // InternalCplus.g:1182:2: (otherlv_0= 'repeat' ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )? otherlv_3= 'when' ( (lv_value_4_0= rulevalue ) ) otherlv_5= 'endrepeat' )
            // InternalCplus.g:1183:3: otherlv_0= 'repeat' ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )? otherlv_3= 'when' ( (lv_value_4_0= rulevalue ) ) otherlv_5= 'endrepeat'
            {
            otherlv_0=(Token)match(input,26,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getRepeatAccess().getRepeatKeyword_0());
            		
            // InternalCplus.g:1187:3: ( ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )* )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( ((LA21_0>=RULE_STRING && LA21_0<=RULE_ID)||(LA21_0>=20 && LA21_0<=22)||(LA21_0>=25 && LA21_0<=26)||LA21_0==30||(LA21_0>=34 && LA21_0<=38)) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalCplus.g:1188:4: ( (lv_statements_1_0= ruleStatements ) ) ( (lv_statements_2_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:1188:4: ( (lv_statements_1_0= ruleStatements ) )
                    // InternalCplus.g:1189:5: (lv_statements_1_0= ruleStatements )
                    {
                    // InternalCplus.g:1189:5: (lv_statements_1_0= ruleStatements )
                    // InternalCplus.g:1190:6: lv_statements_1_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getRepeatAccess().getStatementsStatementsParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_statements_1_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRepeatRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_1_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:1207:4: ( (lv_statements_2_0= ruleStatements ) )*
                    loop20:
                    do {
                        int alt20=2;
                        int LA20_0 = input.LA(1);

                        if ( ((LA20_0>=RULE_STRING && LA20_0<=RULE_ID)||(LA20_0>=20 && LA20_0<=22)||(LA20_0>=25 && LA20_0<=26)||LA20_0==30||(LA20_0>=34 && LA20_0<=38)) ) {
                            alt20=1;
                        }


                        switch (alt20) {
                    	case 1 :
                    	    // InternalCplus.g:1208:5: (lv_statements_2_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:1208:5: (lv_statements_2_0= ruleStatements )
                    	    // InternalCplus.g:1209:6: lv_statements_2_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getRepeatAccess().getStatementsStatementsParserRuleCall_1_1_0());
                    	    					
                    	    pushFollow(FOLLOW_19);
                    	    lv_statements_2_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getRepeatRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_2_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop20;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_3=(Token)match(input,28,FOLLOW_12); 

            			newLeafNode(otherlv_3, grammarAccess.getRepeatAccess().getWhenKeyword_2());
            		
            // InternalCplus.g:1231:3: ( (lv_value_4_0= rulevalue ) )
            // InternalCplus.g:1232:4: (lv_value_4_0= rulevalue )
            {
            // InternalCplus.g:1232:4: (lv_value_4_0= rulevalue )
            // InternalCplus.g:1233:5: lv_value_4_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getRepeatAccess().getValueValueParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_20);
            lv_value_4_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRepeatRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_4_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,29,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getRepeatAccess().getEndrepeatKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRepeat"


    // $ANTLR start "entryRuleFrom"
    // InternalCplus.g:1258:1: entryRuleFrom returns [EObject current=null] : iv_ruleFrom= ruleFrom EOF ;
    public final EObject entryRuleFrom() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFrom = null;


        try {
            // InternalCplus.g:1258:45: (iv_ruleFrom= ruleFrom EOF )
            // InternalCplus.g:1259:2: iv_ruleFrom= ruleFrom EOF
            {
             newCompositeNode(grammarAccess.getFromRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFrom=ruleFrom();

            state._fsp--;

             current =iv_ruleFrom; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFrom"


    // $ANTLR start "ruleFrom"
    // InternalCplus.g:1265:1: ruleFrom returns [EObject current=null] : (otherlv_0= 'from' ( (lv_assignment_1_0= ruleAssignment ) ) otherlv_2= 'to' ( (lv_value_3_0= rulevalue ) ) otherlv_4= 'tohave' ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )? otherlv_7= 'endfor' ) ;
    public final EObject ruleFrom() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_7=null;
        EObject lv_assignment_1_0 = null;

        EObject lv_value_3_0 = null;

        EObject lv_statements_5_0 = null;

        EObject lv_statements_6_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1271:2: ( (otherlv_0= 'from' ( (lv_assignment_1_0= ruleAssignment ) ) otherlv_2= 'to' ( (lv_value_3_0= rulevalue ) ) otherlv_4= 'tohave' ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )? otherlv_7= 'endfor' ) )
            // InternalCplus.g:1272:2: (otherlv_0= 'from' ( (lv_assignment_1_0= ruleAssignment ) ) otherlv_2= 'to' ( (lv_value_3_0= rulevalue ) ) otherlv_4= 'tohave' ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )? otherlv_7= 'endfor' )
            {
            // InternalCplus.g:1272:2: (otherlv_0= 'from' ( (lv_assignment_1_0= ruleAssignment ) ) otherlv_2= 'to' ( (lv_value_3_0= rulevalue ) ) otherlv_4= 'tohave' ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )? otherlv_7= 'endfor' )
            // InternalCplus.g:1273:3: otherlv_0= 'from' ( (lv_assignment_1_0= ruleAssignment ) ) otherlv_2= 'to' ( (lv_value_3_0= rulevalue ) ) otherlv_4= 'tohave' ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )? otherlv_7= 'endfor'
            {
            otherlv_0=(Token)match(input,30,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getFromAccess().getFromKeyword_0());
            		
            // InternalCplus.g:1277:3: ( (lv_assignment_1_0= ruleAssignment ) )
            // InternalCplus.g:1278:4: (lv_assignment_1_0= ruleAssignment )
            {
            // InternalCplus.g:1278:4: (lv_assignment_1_0= ruleAssignment )
            // InternalCplus.g:1279:5: lv_assignment_1_0= ruleAssignment
            {

            					newCompositeNode(grammarAccess.getFromAccess().getAssignmentAssignmentParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_21);
            lv_assignment_1_0=ruleAssignment();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFromRule());
            					}
            					set(
            						current,
            						"assignment",
            						lv_assignment_1_0,
            						"ovanes.cplusdsl.Cplus.Assignment");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,31,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getFromAccess().getToKeyword_2());
            		
            // InternalCplus.g:1300:3: ( (lv_value_3_0= rulevalue ) )
            // InternalCplus.g:1301:4: (lv_value_3_0= rulevalue )
            {
            // InternalCplus.g:1301:4: (lv_value_3_0= rulevalue )
            // InternalCplus.g:1302:5: lv_value_3_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getFromAccess().getValueValueParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_22);
            lv_value_3_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFromRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_3_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,32,FOLLOW_23); 

            			newLeafNode(otherlv_4, grammarAccess.getFromAccess().getTohaveKeyword_4());
            		
            // InternalCplus.g:1323:3: ( ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )* )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( ((LA23_0>=RULE_STRING && LA23_0<=RULE_ID)||(LA23_0>=20 && LA23_0<=22)||(LA23_0>=25 && LA23_0<=26)||LA23_0==30||(LA23_0>=34 && LA23_0<=38)) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalCplus.g:1324:4: ( (lv_statements_5_0= ruleStatements ) ) ( (lv_statements_6_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:1324:4: ( (lv_statements_5_0= ruleStatements ) )
                    // InternalCplus.g:1325:5: (lv_statements_5_0= ruleStatements )
                    {
                    // InternalCplus.g:1325:5: (lv_statements_5_0= ruleStatements )
                    // InternalCplus.g:1326:6: lv_statements_5_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getFromAccess().getStatementsStatementsParserRuleCall_5_0_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_statements_5_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFromRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_5_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:1343:4: ( (lv_statements_6_0= ruleStatements ) )*
                    loop22:
                    do {
                        int alt22=2;
                        int LA22_0 = input.LA(1);

                        if ( ((LA22_0>=RULE_STRING && LA22_0<=RULE_ID)||(LA22_0>=20 && LA22_0<=22)||(LA22_0>=25 && LA22_0<=26)||LA22_0==30||(LA22_0>=34 && LA22_0<=38)) ) {
                            alt22=1;
                        }


                        switch (alt22) {
                    	case 1 :
                    	    // InternalCplus.g:1344:5: (lv_statements_6_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:1344:5: (lv_statements_6_0= ruleStatements )
                    	    // InternalCplus.g:1345:6: lv_statements_6_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getFromAccess().getStatementsStatementsParserRuleCall_5_1_0());
                    	    					
                    	    pushFollow(FOLLOW_23);
                    	    lv_statements_6_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getFromRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_6_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop22;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_7=(Token)match(input,33,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getFromAccess().getEndforKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFrom"


    // $ANTLR start "entryRuleIncrement"
    // InternalCplus.g:1371:1: entryRuleIncrement returns [EObject current=null] : iv_ruleIncrement= ruleIncrement EOF ;
    public final EObject entryRuleIncrement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIncrement = null;


        try {
            // InternalCplus.g:1371:50: (iv_ruleIncrement= ruleIncrement EOF )
            // InternalCplus.g:1372:2: iv_ruleIncrement= ruleIncrement EOF
            {
             newCompositeNode(grammarAccess.getIncrementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIncrement=ruleIncrement();

            state._fsp--;

             current =iv_ruleIncrement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIncrement"


    // $ANTLR start "ruleIncrement"
    // InternalCplus.g:1378:1: ruleIncrement returns [EObject current=null] : ( ( (lv_name_0_0= ruleEString ) ) ( (lv_sign_1_0= ruleinc ) ) ) ;
    public final EObject ruleIncrement() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_name_0_0 = null;

        EObject lv_sign_1_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1384:2: ( ( ( (lv_name_0_0= ruleEString ) ) ( (lv_sign_1_0= ruleinc ) ) ) )
            // InternalCplus.g:1385:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_sign_1_0= ruleinc ) ) )
            {
            // InternalCplus.g:1385:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_sign_1_0= ruleinc ) ) )
            // InternalCplus.g:1386:3: ( (lv_name_0_0= ruleEString ) ) ( (lv_sign_1_0= ruleinc ) )
            {
            // InternalCplus.g:1386:3: ( (lv_name_0_0= ruleEString ) )
            // InternalCplus.g:1387:4: (lv_name_0_0= ruleEString )
            {
            // InternalCplus.g:1387:4: (lv_name_0_0= ruleEString )
            // InternalCplus.g:1388:5: lv_name_0_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getIncrementAccess().getNameEStringParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_24);
            lv_name_0_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIncrementRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_0_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:1405:3: ( (lv_sign_1_0= ruleinc ) )
            // InternalCplus.g:1406:4: (lv_sign_1_0= ruleinc )
            {
            // InternalCplus.g:1406:4: (lv_sign_1_0= ruleinc )
            // InternalCplus.g:1407:5: lv_sign_1_0= ruleinc
            {

            					newCompositeNode(grammarAccess.getIncrementAccess().getSignIncParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_sign_1_0=ruleinc();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIncrementRule());
            					}
            					set(
            						current,
            						"sign",
            						lv_sign_1_0,
            						"ovanes.cplusdsl.Cplus.inc");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIncrement"


    // $ANTLR start "entryRuleTypeVariable"
    // InternalCplus.g:1428:1: entryRuleTypeVariable returns [EObject current=null] : iv_ruleTypeVariable= ruleTypeVariable EOF ;
    public final EObject entryRuleTypeVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTypeVariable = null;


        try {
            // InternalCplus.g:1428:53: (iv_ruleTypeVariable= ruleTypeVariable EOF )
            // InternalCplus.g:1429:2: iv_ruleTypeVariable= ruleTypeVariable EOF
            {
             newCompositeNode(grammarAccess.getTypeVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeVariable=ruleTypeVariable();

            state._fsp--;

             current =iv_ruleTypeVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeVariable"


    // $ANTLR start "ruleTypeVariable"
    // InternalCplus.g:1435:1: ruleTypeVariable returns [EObject current=null] : (otherlv_0= 'integer' | otherlv_1= 'character' | otherlv_2= 'decimal' | otherlv_3= 'boolean' | otherlv_4= 'string' ) ;
    public final EObject ruleTypeVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalCplus.g:1441:2: ( (otherlv_0= 'integer' | otherlv_1= 'character' | otherlv_2= 'decimal' | otherlv_3= 'boolean' | otherlv_4= 'string' ) )
            // InternalCplus.g:1442:2: (otherlv_0= 'integer' | otherlv_1= 'character' | otherlv_2= 'decimal' | otherlv_3= 'boolean' | otherlv_4= 'string' )
            {
            // InternalCplus.g:1442:2: (otherlv_0= 'integer' | otherlv_1= 'character' | otherlv_2= 'decimal' | otherlv_3= 'boolean' | otherlv_4= 'string' )
            int alt24=5;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt24=1;
                }
                break;
            case 35:
                {
                alt24=2;
                }
                break;
            case 36:
                {
                alt24=3;
                }
                break;
            case 37:
                {
                alt24=4;
                }
                break;
            case 38:
                {
                alt24=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalCplus.g:1443:3: otherlv_0= 'integer'
                    {
                    otherlv_0=(Token)match(input,34,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getTypeVariableAccess().getIntegerKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:1448:3: otherlv_1= 'character'
                    {
                    otherlv_1=(Token)match(input,35,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getTypeVariableAccess().getCharacterKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalCplus.g:1453:3: otherlv_2= 'decimal'
                    {
                    otherlv_2=(Token)match(input,36,FOLLOW_2); 

                    			newLeafNode(otherlv_2, grammarAccess.getTypeVariableAccess().getDecimalKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalCplus.g:1458:3: otherlv_3= 'boolean'
                    {
                    otherlv_3=(Token)match(input,37,FOLLOW_2); 

                    			newLeafNode(otherlv_3, grammarAccess.getTypeVariableAccess().getBooleanKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalCplus.g:1463:3: otherlv_4= 'string'
                    {
                    otherlv_4=(Token)match(input,38,FOLLOW_2); 

                    			newLeafNode(otherlv_4, grammarAccess.getTypeVariableAccess().getStringKeyword_4());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeVariable"


    // $ANTLR start "entryRuleVariable"
    // InternalCplus.g:1471:1: entryRuleVariable returns [EObject current=null] : iv_ruleVariable= ruleVariable EOF ;
    public final EObject entryRuleVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariable = null;


        try {
            // InternalCplus.g:1471:49: (iv_ruleVariable= ruleVariable EOF )
            // InternalCplus.g:1472:2: iv_ruleVariable= ruleVariable EOF
            {
             newCompositeNode(grammarAccess.getVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariable=ruleVariable();

            state._fsp--;

             current =iv_ruleVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariable"


    // $ANTLR start "ruleVariable"
    // InternalCplus.g:1478:1: ruleVariable returns [EObject current=null] : ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* ) ;
    public final EObject ruleVariable() throws RecognitionException {
        EObject current = null;

        Token lv_Mat_1_0=null;
        AntlrDatatypeRuleToken lv_name_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1484:2: ( ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* ) )
            // InternalCplus.g:1485:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* )
            {
            // InternalCplus.g:1485:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* )
            // InternalCplus.g:1486:3: ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )*
            {
            // InternalCplus.g:1486:3: ( (lv_name_0_0= ruleEString ) )
            // InternalCplus.g:1487:4: (lv_name_0_0= ruleEString )
            {
            // InternalCplus.g:1487:4: (lv_name_0_0= ruleEString )
            // InternalCplus.g:1488:5: lv_name_0_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getVariableAccess().getNameEStringParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_25);
            lv_name_0_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariableRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_0_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:1505:3: ( (lv_Mat_1_0= RULE_MATRIX ) )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==RULE_MATRIX) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalCplus.g:1506:4: (lv_Mat_1_0= RULE_MATRIX )
            	    {
            	    // InternalCplus.g:1506:4: (lv_Mat_1_0= RULE_MATRIX )
            	    // InternalCplus.g:1507:5: lv_Mat_1_0= RULE_MATRIX
            	    {
            	    lv_Mat_1_0=(Token)match(input,RULE_MATRIX,FOLLOW_25); 

            	    					newLeafNode(lv_Mat_1_0, grammarAccess.getVariableAccess().getMatMATRIXTerminalRuleCall_1_0());
            	    				

            	    					if (current==null) {
            	    						current = createModelElement(grammarAccess.getVariableRule());
            	    					}
            	    					addWithLastConsumed(
            	    						current,
            	    						"Mat",
            	    						lv_Mat_1_0,
            	    						"ovanes.cplusdsl.Cplus.MATRIX");
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariable"


    // $ANTLR start "entryRuleVariableID"
    // InternalCplus.g:1527:1: entryRuleVariableID returns [EObject current=null] : iv_ruleVariableID= ruleVariableID EOF ;
    public final EObject entryRuleVariableID() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableID = null;


        try {
            // InternalCplus.g:1527:51: (iv_ruleVariableID= ruleVariableID EOF )
            // InternalCplus.g:1528:2: iv_ruleVariableID= ruleVariableID EOF
            {
             newCompositeNode(grammarAccess.getVariableIDRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableID=ruleVariableID();

            state._fsp--;

             current =iv_ruleVariableID; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableID"


    // $ANTLR start "ruleVariableID"
    // InternalCplus.g:1534:1: ruleVariableID returns [EObject current=null] : ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* ) ;
    public final EObject ruleVariableID() throws RecognitionException {
        EObject current = null;

        Token lv_Mat_1_0=null;
        AntlrDatatypeRuleToken lv_name_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1540:2: ( ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* ) )
            // InternalCplus.g:1541:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* )
            {
            // InternalCplus.g:1541:2: ( ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )* )
            // InternalCplus.g:1542:3: ( (lv_name_0_0= ruleEString ) ) ( (lv_Mat_1_0= RULE_MATRIX ) )*
            {
            // InternalCplus.g:1542:3: ( (lv_name_0_0= ruleEString ) )
            // InternalCplus.g:1543:4: (lv_name_0_0= ruleEString )
            {
            // InternalCplus.g:1543:4: (lv_name_0_0= ruleEString )
            // InternalCplus.g:1544:5: lv_name_0_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getVariableIDAccess().getNameEStringParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_25);
            lv_name_0_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariableIDRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_0_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:1561:3: ( (lv_Mat_1_0= RULE_MATRIX ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==RULE_MATRIX) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalCplus.g:1562:4: (lv_Mat_1_0= RULE_MATRIX )
            	    {
            	    // InternalCplus.g:1562:4: (lv_Mat_1_0= RULE_MATRIX )
            	    // InternalCplus.g:1563:5: lv_Mat_1_0= RULE_MATRIX
            	    {
            	    lv_Mat_1_0=(Token)match(input,RULE_MATRIX,FOLLOW_25); 

            	    					newLeafNode(lv_Mat_1_0, grammarAccess.getVariableIDAccess().getMatMATRIXTerminalRuleCall_1_0());
            	    				

            	    					if (current==null) {
            	    						current = createModelElement(grammarAccess.getVariableIDRule());
            	    					}
            	    					addWithLastConsumed(
            	    						current,
            	    						"Mat",
            	    						lv_Mat_1_0,
            	    						"ovanes.cplusdsl.Cplus.MATRIX");
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableID"


    // $ANTLR start "entryRuleConstString"
    // InternalCplus.g:1583:1: entryRuleConstString returns [EObject current=null] : iv_ruleConstString= ruleConstString EOF ;
    public final EObject entryRuleConstString() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstString = null;


        try {
            // InternalCplus.g:1583:52: (iv_ruleConstString= ruleConstString EOF )
            // InternalCplus.g:1584:2: iv_ruleConstString= ruleConstString EOF
            {
             newCompositeNode(grammarAccess.getConstStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstString=ruleConstString();

            state._fsp--;

             current =iv_ruleConstString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstString"


    // $ANTLR start "ruleConstString"
    // InternalCplus.g:1590:1: ruleConstString returns [EObject current=null] : ( (lv_content_0_0= RULE_CAD ) ) ;
    public final EObject ruleConstString() throws RecognitionException {
        EObject current = null;

        Token lv_content_0_0=null;


        	enterRule();

        try {
            // InternalCplus.g:1596:2: ( ( (lv_content_0_0= RULE_CAD ) ) )
            // InternalCplus.g:1597:2: ( (lv_content_0_0= RULE_CAD ) )
            {
            // InternalCplus.g:1597:2: ( (lv_content_0_0= RULE_CAD ) )
            // InternalCplus.g:1598:3: (lv_content_0_0= RULE_CAD )
            {
            // InternalCplus.g:1598:3: (lv_content_0_0= RULE_CAD )
            // InternalCplus.g:1599:4: lv_content_0_0= RULE_CAD
            {
            lv_content_0_0=(Token)match(input,RULE_CAD,FOLLOW_2); 

            				newLeafNode(lv_content_0_0, grammarAccess.getConstStringAccess().getContentCADTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getConstStringRule());
            				}
            				setWithLastConsumed(
            					current,
            					"content",
            					lv_content_0_0,
            					"ovanes.cplusdsl.Cplus.CAD");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstString"


    // $ANTLR start "entryRuleInteger"
    // InternalCplus.g:1618:1: entryRuleInteger returns [EObject current=null] : iv_ruleInteger= ruleInteger EOF ;
    public final EObject entryRuleInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInteger = null;


        try {
            // InternalCplus.g:1618:48: (iv_ruleInteger= ruleInteger EOF )
            // InternalCplus.g:1619:2: iv_ruleInteger= ruleInteger EOF
            {
             newCompositeNode(grammarAccess.getIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInteger=ruleInteger();

            state._fsp--;

             current =iv_ruleInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInteger"


    // $ANTLR start "ruleInteger"
    // InternalCplus.g:1625:1: ruleInteger returns [EObject current=null] : ( (lv_value_0_0= ruleEInt ) ) ;
    public final EObject ruleInteger() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_value_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1631:2: ( ( (lv_value_0_0= ruleEInt ) ) )
            // InternalCplus.g:1632:2: ( (lv_value_0_0= ruleEInt ) )
            {
            // InternalCplus.g:1632:2: ( (lv_value_0_0= ruleEInt ) )
            // InternalCplus.g:1633:3: (lv_value_0_0= ruleEInt )
            {
            // InternalCplus.g:1633:3: (lv_value_0_0= ruleEInt )
            // InternalCplus.g:1634:4: lv_value_0_0= ruleEInt
            {

            				newCompositeNode(grammarAccess.getIntegerAccess().getValueEIntParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_value_0_0=ruleEInt();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getIntegerRule());
            				}
            				set(
            					current,
            					"value",
            					lv_value_0_0,
            					"ovanes.cplusdsl.Cplus.EInt");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInteger"


    // $ANTLR start "entryRuleIntDecimal"
    // InternalCplus.g:1654:1: entryRuleIntDecimal returns [EObject current=null] : iv_ruleIntDecimal= ruleIntDecimal EOF ;
    public final EObject entryRuleIntDecimal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIntDecimal = null;


        try {
            // InternalCplus.g:1654:51: (iv_ruleIntDecimal= ruleIntDecimal EOF )
            // InternalCplus.g:1655:2: iv_ruleIntDecimal= ruleIntDecimal EOF
            {
             newCompositeNode(grammarAccess.getIntDecimalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIntDecimal=ruleIntDecimal();

            state._fsp--;

             current =iv_ruleIntDecimal; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIntDecimal"


    // $ANTLR start "ruleIntDecimal"
    // InternalCplus.g:1661:1: ruleIntDecimal returns [EObject current=null] : ( (lv_vlaue_0_0= ruleEFloat ) ) ;
    public final EObject ruleIntDecimal() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_vlaue_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1667:2: ( ( (lv_vlaue_0_0= ruleEFloat ) ) )
            // InternalCplus.g:1668:2: ( (lv_vlaue_0_0= ruleEFloat ) )
            {
            // InternalCplus.g:1668:2: ( (lv_vlaue_0_0= ruleEFloat ) )
            // InternalCplus.g:1669:3: (lv_vlaue_0_0= ruleEFloat )
            {
            // InternalCplus.g:1669:3: (lv_vlaue_0_0= ruleEFloat )
            // InternalCplus.g:1670:4: lv_vlaue_0_0= ruleEFloat
            {

            				newCompositeNode(grammarAccess.getIntDecimalAccess().getVlaueEFloatParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_vlaue_0_0=ruleEFloat();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getIntDecimalRule());
            				}
            				set(
            					current,
            					"vlaue",
            					lv_vlaue_0_0,
            					"ovanes.cplusdsl.Cplus.EFloat");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntDecimal"


    // $ANTLR start "entryRuleValBoolean"
    // InternalCplus.g:1690:1: entryRuleValBoolean returns [EObject current=null] : iv_ruleValBoolean= ruleValBoolean EOF ;
    public final EObject entryRuleValBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValBoolean = null;


        try {
            // InternalCplus.g:1690:51: (iv_ruleValBoolean= ruleValBoolean EOF )
            // InternalCplus.g:1691:2: iv_ruleValBoolean= ruleValBoolean EOF
            {
             newCompositeNode(grammarAccess.getValBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValBoolean=ruleValBoolean();

            state._fsp--;

             current =iv_ruleValBoolean; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValBoolean"


    // $ANTLR start "ruleValBoolean"
    // InternalCplus.g:1697:1: ruleValBoolean returns [EObject current=null] : ( (lv_value_0_0= rulebool ) ) ;
    public final EObject ruleValBoolean() throws RecognitionException {
        EObject current = null;

        EObject lv_value_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1703:2: ( ( (lv_value_0_0= rulebool ) ) )
            // InternalCplus.g:1704:2: ( (lv_value_0_0= rulebool ) )
            {
            // InternalCplus.g:1704:2: ( (lv_value_0_0= rulebool ) )
            // InternalCplus.g:1705:3: (lv_value_0_0= rulebool )
            {
            // InternalCplus.g:1705:3: (lv_value_0_0= rulebool )
            // InternalCplus.g:1706:4: lv_value_0_0= rulebool
            {

            				newCompositeNode(grammarAccess.getValBooleanAccess().getValueBoolParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_value_0_0=rulebool();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getValBooleanRule());
            				}
            				set(
            					current,
            					"value",
            					lv_value_0_0,
            					"ovanes.cplusdsl.Cplus.bool");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValBoolean"


    // $ANTLR start "entryRuleEInt"
    // InternalCplus.g:1726:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalCplus.g:1726:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalCplus.g:1727:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalCplus.g:1733:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalCplus.g:1739:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalCplus.g:1740:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalCplus.g:1740:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalCplus.g:1741:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalCplus.g:1741:3: (kw= '-' )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==39) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalCplus.g:1742:4: kw= '-'
                    {
                    kw=(Token)match(input,39,FOLLOW_26); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEFloat"
    // InternalCplus.g:1759:1: entryRuleEFloat returns [String current=null] : iv_ruleEFloat= ruleEFloat EOF ;
    public final String entryRuleEFloat() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEFloat = null;


        try {
            // InternalCplus.g:1759:46: (iv_ruleEFloat= ruleEFloat EOF )
            // InternalCplus.g:1760:2: iv_ruleEFloat= ruleEFloat EOF
            {
             newCompositeNode(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEFloat=ruleEFloat();

            state._fsp--;

             current =iv_ruleEFloat.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalCplus.g:1766:1: ruleEFloat returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEFloat() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalCplus.g:1772:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalCplus.g:1773:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalCplus.g:1773:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalCplus.g:1774:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalCplus.g:1774:3: (kw= '-' )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==39) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalCplus.g:1775:4: kw= '-'
                    {
                    kw=(Token)match(input,39,FOLLOW_27); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalCplus.g:1781:3: (this_INT_1= RULE_INT )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_INT) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalCplus.g:1782:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_28); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,40,FOLLOW_26); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEFloatAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_29); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3());
            		
            // InternalCplus.g:1802:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( ((LA32_0>=41 && LA32_0<=42)) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalCplus.g:1803:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalCplus.g:1803:4: (kw= 'E' | kw= 'e' )
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==41) ) {
                        alt30=1;
                    }
                    else if ( (LA30_0==42) ) {
                        alt30=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 30, 0, input);

                        throw nvae;
                    }
                    switch (alt30) {
                        case 1 :
                            // InternalCplus.g:1804:5: kw= 'E'
                            {
                            kw=(Token)match(input,41,FOLLOW_30); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalCplus.g:1810:5: kw= 'e'
                            {
                            kw=(Token)match(input,42,FOLLOW_30); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalCplus.g:1816:4: (kw= '-' )?
                    int alt31=2;
                    int LA31_0 = input.LA(1);

                    if ( (LA31_0==39) ) {
                        alt31=1;
                    }
                    switch (alt31) {
                        case 1 :
                            // InternalCplus.g:1817:5: kw= '-'
                            {
                            kw=(Token)match(input,39,FOLLOW_26); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "entryRulebool"
    // InternalCplus.g:1835:1: entryRulebool returns [EObject current=null] : iv_rulebool= rulebool EOF ;
    public final EObject entryRulebool() throws RecognitionException {
        EObject current = null;

        EObject iv_rulebool = null;


        try {
            // InternalCplus.g:1835:45: (iv_rulebool= rulebool EOF )
            // InternalCplus.g:1836:2: iv_rulebool= rulebool EOF
            {
             newCompositeNode(grammarAccess.getBoolRule()); 
            pushFollow(FOLLOW_1);
            iv_rulebool=rulebool();

            state._fsp--;

             current =iv_rulebool; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulebool"


    // $ANTLR start "rulebool"
    // InternalCplus.g:1842:1: rulebool returns [EObject current=null] : (otherlv_0= 'true' | otherlv_1= 'false' ) ;
    public final EObject rulebool() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalCplus.g:1848:2: ( (otherlv_0= 'true' | otherlv_1= 'false' ) )
            // InternalCplus.g:1849:2: (otherlv_0= 'true' | otherlv_1= 'false' )
            {
            // InternalCplus.g:1849:2: (otherlv_0= 'true' | otherlv_1= 'false' )
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==43) ) {
                alt33=1;
            }
            else if ( (LA33_0==44) ) {
                alt33=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }
            switch (alt33) {
                case 1 :
                    // InternalCplus.g:1850:3: otherlv_0= 'true'
                    {
                    otherlv_0=(Token)match(input,43,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getBoolAccess().getTrueKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:1855:3: otherlv_1= 'false'
                    {
                    otherlv_1=(Token)match(input,44,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getBoolAccess().getFalseKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulebool"


    // $ANTLR start "entryRuleoperation"
    // InternalCplus.g:1863:1: entryRuleoperation returns [EObject current=null] : iv_ruleoperation= ruleoperation EOF ;
    public final EObject entryRuleoperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoperation = null;


        try {
            // InternalCplus.g:1863:50: (iv_ruleoperation= ruleoperation EOF )
            // InternalCplus.g:1864:2: iv_ruleoperation= ruleoperation EOF
            {
             newCompositeNode(grammarAccess.getOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleoperation=ruleoperation();

            state._fsp--;

             current =iv_ruleoperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoperation"


    // $ANTLR start "ruleoperation"
    // InternalCplus.g:1870:1: ruleoperation returns [EObject current=null] : (otherlv_0= '(' ( (lv_op_left_1_0= ruleoperator_left ) ) ( (lv_sign_op_2_0= rulesign ) ) ( (lv_op_right_3_0= ruleoperator_right ) ) otherlv_4= ')' ) ;
    public final EObject ruleoperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_4=null;
        EObject lv_op_left_1_0 = null;

        EObject lv_sign_op_2_0 = null;

        EObject lv_op_right_3_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:1876:2: ( (otherlv_0= '(' ( (lv_op_left_1_0= ruleoperator_left ) ) ( (lv_sign_op_2_0= rulesign ) ) ( (lv_op_right_3_0= ruleoperator_right ) ) otherlv_4= ')' ) )
            // InternalCplus.g:1877:2: (otherlv_0= '(' ( (lv_op_left_1_0= ruleoperator_left ) ) ( (lv_sign_op_2_0= rulesign ) ) ( (lv_op_right_3_0= ruleoperator_right ) ) otherlv_4= ')' )
            {
            // InternalCplus.g:1877:2: (otherlv_0= '(' ( (lv_op_left_1_0= ruleoperator_left ) ) ( (lv_sign_op_2_0= rulesign ) ) ( (lv_op_right_3_0= ruleoperator_right ) ) otherlv_4= ')' )
            // InternalCplus.g:1878:3: otherlv_0= '(' ( (lv_op_left_1_0= ruleoperator_left ) ) ( (lv_sign_op_2_0= rulesign ) ) ( (lv_op_right_3_0= ruleoperator_right ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,17,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getOperationAccess().getLeftParenthesisKeyword_0());
            		
            // InternalCplus.g:1882:3: ( (lv_op_left_1_0= ruleoperator_left ) )
            // InternalCplus.g:1883:4: (lv_op_left_1_0= ruleoperator_left )
            {
            // InternalCplus.g:1883:4: (lv_op_left_1_0= ruleoperator_left )
            // InternalCplus.g:1884:5: lv_op_left_1_0= ruleoperator_left
            {

            					newCompositeNode(grammarAccess.getOperationAccess().getOp_leftOperator_leftParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_31);
            lv_op_left_1_0=ruleoperator_left();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOperationRule());
            					}
            					set(
            						current,
            						"op_left",
            						lv_op_left_1_0,
            						"ovanes.cplusdsl.Cplus.operator_left");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:1901:3: ( (lv_sign_op_2_0= rulesign ) )
            // InternalCplus.g:1902:4: (lv_sign_op_2_0= rulesign )
            {
            // InternalCplus.g:1902:4: (lv_sign_op_2_0= rulesign )
            // InternalCplus.g:1903:5: lv_sign_op_2_0= rulesign
            {

            					newCompositeNode(grammarAccess.getOperationAccess().getSign_opSignParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_12);
            lv_sign_op_2_0=rulesign();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOperationRule());
            					}
            					set(
            						current,
            						"sign_op",
            						lv_sign_op_2_0,
            						"ovanes.cplusdsl.Cplus.sign");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:1920:3: ( (lv_op_right_3_0= ruleoperator_right ) )
            // InternalCplus.g:1921:4: (lv_op_right_3_0= ruleoperator_right )
            {
            // InternalCplus.g:1921:4: (lv_op_right_3_0= ruleoperator_right )
            // InternalCplus.g:1922:5: lv_op_right_3_0= ruleoperator_right
            {

            					newCompositeNode(grammarAccess.getOperationAccess().getOp_rightOperator_rightParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_13);
            lv_op_right_3_0=ruleoperator_right();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOperationRule());
            					}
            					set(
            						current,
            						"op_right",
            						lv_op_right_3_0,
            						"ovanes.cplusdsl.Cplus.operator_right");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getOperationAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoperation"


    // $ANTLR start "entryRulesign"
    // InternalCplus.g:1947:1: entryRulesign returns [EObject current=null] : iv_rulesign= rulesign EOF ;
    public final EObject entryRulesign() throws RecognitionException {
        EObject current = null;

        EObject iv_rulesign = null;


        try {
            // InternalCplus.g:1947:45: (iv_rulesign= rulesign EOF )
            // InternalCplus.g:1948:2: iv_rulesign= rulesign EOF
            {
             newCompositeNode(grammarAccess.getSignRule()); 
            pushFollow(FOLLOW_1);
            iv_rulesign=rulesign();

            state._fsp--;

             current =iv_rulesign; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulesign"


    // $ANTLR start "rulesign"
    // InternalCplus.g:1954:1: rulesign returns [EObject current=null] : ( () (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' ) ) ;
    public final EObject rulesign() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;


        	enterRule();

        try {
            // InternalCplus.g:1960:2: ( ( () (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' ) ) )
            // InternalCplus.g:1961:2: ( () (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' ) )
            {
            // InternalCplus.g:1961:2: ( () (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' ) )
            // InternalCplus.g:1962:3: () (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' )
            {
            // InternalCplus.g:1962:3: ()
            // InternalCplus.g:1963:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSignAccess().getSignAction_0(),
            					current);
            			

            }

            // InternalCplus.g:1969:3: (otherlv_1= '+' | otherlv_2= '-' | otherlv_3= '*' | otherlv_4= '/' | otherlv_5= '<' | otherlv_6= '>' | otherlv_7= '>=' | otherlv_8= '<=' | otherlv_9= 'y' | otherlv_10= 'o' | otherlv_11= '==' | otherlv_12= '!=' )
            int alt34=12;
            switch ( input.LA(1) ) {
            case 45:
                {
                alt34=1;
                }
                break;
            case 39:
                {
                alt34=2;
                }
                break;
            case 46:
                {
                alt34=3;
                }
                break;
            case 47:
                {
                alt34=4;
                }
                break;
            case 48:
                {
                alt34=5;
                }
                break;
            case 49:
                {
                alt34=6;
                }
                break;
            case 50:
                {
                alt34=7;
                }
                break;
            case 51:
                {
                alt34=8;
                }
                break;
            case 52:
                {
                alt34=9;
                }
                break;
            case 53:
                {
                alt34=10;
                }
                break;
            case 54:
                {
                alt34=11;
                }
                break;
            case 55:
                {
                alt34=12;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }

            switch (alt34) {
                case 1 :
                    // InternalCplus.g:1970:4: otherlv_1= '+'
                    {
                    otherlv_1=(Token)match(input,45,FOLLOW_2); 

                    				newLeafNode(otherlv_1, grammarAccess.getSignAccess().getPlusSignKeyword_1_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalCplus.g:1975:4: otherlv_2= '-'
                    {
                    otherlv_2=(Token)match(input,39,FOLLOW_2); 

                    				newLeafNode(otherlv_2, grammarAccess.getSignAccess().getHyphenMinusKeyword_1_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalCplus.g:1980:4: otherlv_3= '*'
                    {
                    otherlv_3=(Token)match(input,46,FOLLOW_2); 

                    				newLeafNode(otherlv_3, grammarAccess.getSignAccess().getAsteriskKeyword_1_2());
                    			

                    }
                    break;
                case 4 :
                    // InternalCplus.g:1985:4: otherlv_4= '/'
                    {
                    otherlv_4=(Token)match(input,47,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getSignAccess().getSolidusKeyword_1_3());
                    			

                    }
                    break;
                case 5 :
                    // InternalCplus.g:1990:4: otherlv_5= '<'
                    {
                    otherlv_5=(Token)match(input,48,FOLLOW_2); 

                    				newLeafNode(otherlv_5, grammarAccess.getSignAccess().getLessThanSignKeyword_1_4());
                    			

                    }
                    break;
                case 6 :
                    // InternalCplus.g:1995:4: otherlv_6= '>'
                    {
                    otherlv_6=(Token)match(input,49,FOLLOW_2); 

                    				newLeafNode(otherlv_6, grammarAccess.getSignAccess().getGreaterThanSignKeyword_1_5());
                    			

                    }
                    break;
                case 7 :
                    // InternalCplus.g:2000:4: otherlv_7= '>='
                    {
                    otherlv_7=(Token)match(input,50,FOLLOW_2); 

                    				newLeafNode(otherlv_7, grammarAccess.getSignAccess().getGreaterThanSignEqualsSignKeyword_1_6());
                    			

                    }
                    break;
                case 8 :
                    // InternalCplus.g:2005:4: otherlv_8= '<='
                    {
                    otherlv_8=(Token)match(input,51,FOLLOW_2); 

                    				newLeafNode(otherlv_8, grammarAccess.getSignAccess().getLessThanSignEqualsSignKeyword_1_7());
                    			

                    }
                    break;
                case 9 :
                    // InternalCplus.g:2010:4: otherlv_9= 'y'
                    {
                    otherlv_9=(Token)match(input,52,FOLLOW_2); 

                    				newLeafNode(otherlv_9, grammarAccess.getSignAccess().getYKeyword_1_8());
                    			

                    }
                    break;
                case 10 :
                    // InternalCplus.g:2015:4: otherlv_10= 'o'
                    {
                    otherlv_10=(Token)match(input,53,FOLLOW_2); 

                    				newLeafNode(otherlv_10, grammarAccess.getSignAccess().getOKeyword_1_9());
                    			

                    }
                    break;
                case 11 :
                    // InternalCplus.g:2020:4: otherlv_11= '=='
                    {
                    otherlv_11=(Token)match(input,54,FOLLOW_2); 

                    				newLeafNode(otherlv_11, grammarAccess.getSignAccess().getEqualsSignEqualsSignKeyword_1_10());
                    			

                    }
                    break;
                case 12 :
                    // InternalCplus.g:2025:4: otherlv_12= '!='
                    {
                    otherlv_12=(Token)match(input,55,FOLLOW_2); 

                    				newLeafNode(otherlv_12, grammarAccess.getSignAccess().getExclamationMarkEqualsSignKeyword_1_11());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulesign"


    // $ANTLR start "entryRuleoperator_left"
    // InternalCplus.g:2034:1: entryRuleoperator_left returns [EObject current=null] : iv_ruleoperator_left= ruleoperator_left EOF ;
    public final EObject entryRuleoperator_left() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoperator_left = null;


        try {
            // InternalCplus.g:2034:54: (iv_ruleoperator_left= ruleoperator_left EOF )
            // InternalCplus.g:2035:2: iv_ruleoperator_left= ruleoperator_left EOF
            {
             newCompositeNode(grammarAccess.getOperator_leftRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleoperator_left=ruleoperator_left();

            state._fsp--;

             current =iv_ruleoperator_left; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoperator_left"


    // $ANTLR start "ruleoperator_left"
    // InternalCplus.g:2041:1: ruleoperator_left returns [EObject current=null] : ( (lv_oper_left_0_0= rulevalue ) ) ;
    public final EObject ruleoperator_left() throws RecognitionException {
        EObject current = null;

        EObject lv_oper_left_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2047:2: ( ( (lv_oper_left_0_0= rulevalue ) ) )
            // InternalCplus.g:2048:2: ( (lv_oper_left_0_0= rulevalue ) )
            {
            // InternalCplus.g:2048:2: ( (lv_oper_left_0_0= rulevalue ) )
            // InternalCplus.g:2049:3: (lv_oper_left_0_0= rulevalue )
            {
            // InternalCplus.g:2049:3: (lv_oper_left_0_0= rulevalue )
            // InternalCplus.g:2050:4: lv_oper_left_0_0= rulevalue
            {

            				newCompositeNode(grammarAccess.getOperator_leftAccess().getOper_leftValueParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_oper_left_0_0=rulevalue();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getOperator_leftRule());
            				}
            				set(
            					current,
            					"oper_left",
            					lv_oper_left_0_0,
            					"ovanes.cplusdsl.Cplus.value");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoperator_left"


    // $ANTLR start "entryRuleoperator_right"
    // InternalCplus.g:2070:1: entryRuleoperator_right returns [EObject current=null] : iv_ruleoperator_right= ruleoperator_right EOF ;
    public final EObject entryRuleoperator_right() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleoperator_right = null;


        try {
            // InternalCplus.g:2070:55: (iv_ruleoperator_right= ruleoperator_right EOF )
            // InternalCplus.g:2071:2: iv_ruleoperator_right= ruleoperator_right EOF
            {
             newCompositeNode(grammarAccess.getOperator_rightRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleoperator_right=ruleoperator_right();

            state._fsp--;

             current =iv_ruleoperator_right; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleoperator_right"


    // $ANTLR start "ruleoperator_right"
    // InternalCplus.g:2077:1: ruleoperator_right returns [EObject current=null] : ( (lv_oper_right_0_0= rulevalue ) ) ;
    public final EObject ruleoperator_right() throws RecognitionException {
        EObject current = null;

        EObject lv_oper_right_0_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2083:2: ( ( (lv_oper_right_0_0= rulevalue ) ) )
            // InternalCplus.g:2084:2: ( (lv_oper_right_0_0= rulevalue ) )
            {
            // InternalCplus.g:2084:2: ( (lv_oper_right_0_0= rulevalue ) )
            // InternalCplus.g:2085:3: (lv_oper_right_0_0= rulevalue )
            {
            // InternalCplus.g:2085:3: (lv_oper_right_0_0= rulevalue )
            // InternalCplus.g:2086:4: lv_oper_right_0_0= rulevalue
            {

            				newCompositeNode(grammarAccess.getOperator_rightAccess().getOper_rightValueParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_oper_right_0_0=rulevalue();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getOperator_rightRule());
            				}
            				set(
            					current,
            					"oper_right",
            					lv_oper_right_0_0,
            					"ovanes.cplusdsl.Cplus.value");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleoperator_right"


    // $ANTLR start "entryRuleElseif"
    // InternalCplus.g:2106:1: entryRuleElseif returns [EObject current=null] : iv_ruleElseif= ruleElseif EOF ;
    public final EObject entryRuleElseif() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElseif = null;


        try {
            // InternalCplus.g:2106:47: (iv_ruleElseif= ruleElseif EOF )
            // InternalCplus.g:2107:2: iv_ruleElseif= ruleElseif EOF
            {
             newCompositeNode(grammarAccess.getElseifRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElseif=ruleElseif();

            state._fsp--;

             current =iv_ruleElseif; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElseif"


    // $ANTLR start "ruleElseif"
    // InternalCplus.g:2113:1: ruleElseif returns [EObject current=null] : ( () otherlv_1= 'elseif' ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )? ) ;
    public final EObject ruleElseif() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_statements_2_0 = null;

        EObject lv_statements_3_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2119:2: ( ( () otherlv_1= 'elseif' ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )? ) )
            // InternalCplus.g:2120:2: ( () otherlv_1= 'elseif' ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )? )
            {
            // InternalCplus.g:2120:2: ( () otherlv_1= 'elseif' ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )? )
            // InternalCplus.g:2121:3: () otherlv_1= 'elseif' ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )?
            {
            // InternalCplus.g:2121:3: ()
            // InternalCplus.g:2122:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getElseifAccess().getElseifAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,56,FOLLOW_32); 

            			newLeafNode(otherlv_1, grammarAccess.getElseifAccess().getElseifKeyword_1());
            		
            // InternalCplus.g:2132:3: ( ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )* )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( ((LA36_0>=RULE_STRING && LA36_0<=RULE_ID)||(LA36_0>=20 && LA36_0<=22)||(LA36_0>=25 && LA36_0<=26)||LA36_0==30||(LA36_0>=34 && LA36_0<=38)) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalCplus.g:2133:4: ( (lv_statements_2_0= ruleStatements ) ) ( (lv_statements_3_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:2133:4: ( (lv_statements_2_0= ruleStatements ) )
                    // InternalCplus.g:2134:5: (lv_statements_2_0= ruleStatements )
                    {
                    // InternalCplus.g:2134:5: (lv_statements_2_0= ruleStatements )
                    // InternalCplus.g:2135:6: lv_statements_2_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getElseifAccess().getStatementsStatementsParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_32);
                    lv_statements_2_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getElseifRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_2_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:2152:4: ( (lv_statements_3_0= ruleStatements ) )*
                    loop35:
                    do {
                        int alt35=2;
                        int LA35_0 = input.LA(1);

                        if ( ((LA35_0>=RULE_STRING && LA35_0<=RULE_ID)||(LA35_0>=20 && LA35_0<=22)||(LA35_0>=25 && LA35_0<=26)||LA35_0==30||(LA35_0>=34 && LA35_0<=38)) ) {
                            alt35=1;
                        }


                        switch (alt35) {
                    	case 1 :
                    	    // InternalCplus.g:2153:5: (lv_statements_3_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:2153:5: (lv_statements_3_0= ruleStatements )
                    	    // InternalCplus.g:2154:6: lv_statements_3_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getElseifAccess().getStatementsStatementsParserRuleCall_2_1_0());
                    	    					
                    	    pushFollow(FOLLOW_32);
                    	    lv_statements_3_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getElseifRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_3_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop35;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElseif"


    // $ANTLR start "entryRuleinc"
    // InternalCplus.g:2176:1: entryRuleinc returns [EObject current=null] : iv_ruleinc= ruleinc EOF ;
    public final EObject entryRuleinc() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleinc = null;


        try {
            // InternalCplus.g:2176:44: (iv_ruleinc= ruleinc EOF )
            // InternalCplus.g:2177:2: iv_ruleinc= ruleinc EOF
            {
             newCompositeNode(grammarAccess.getIncRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleinc=ruleinc();

            state._fsp--;

             current =iv_ruleinc; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleinc"


    // $ANTLR start "ruleinc"
    // InternalCplus.g:2183:1: ruleinc returns [EObject current=null] : (otherlv_0= '++' | otherlv_1= '--' ) ;
    public final EObject ruleinc() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalCplus.g:2189:2: ( (otherlv_0= '++' | otherlv_1= '--' ) )
            // InternalCplus.g:2190:2: (otherlv_0= '++' | otherlv_1= '--' )
            {
            // InternalCplus.g:2190:2: (otherlv_0= '++' | otherlv_1= '--' )
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==57) ) {
                alt37=1;
            }
            else if ( (LA37_0==58) ) {
                alt37=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 37, 0, input);

                throw nvae;
            }
            switch (alt37) {
                case 1 :
                    // InternalCplus.g:2191:3: otherlv_0= '++'
                    {
                    otherlv_0=(Token)match(input,57,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getIncAccess().getPlusSignPlusSignKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:2196:3: otherlv_1= '--'
                    {
                    otherlv_1=(Token)match(input,58,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getIncAccess().getHyphenMinusHyphenMinusKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleinc"


    // $ANTLR start "entryRuleParameterFunction"
    // InternalCplus.g:2204:1: entryRuleParameterFunction returns [EObject current=null] : iv_ruleParameterFunction= ruleParameterFunction EOF ;
    public final EObject entryRuleParameterFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParameterFunction = null;


        try {
            // InternalCplus.g:2204:58: (iv_ruleParameterFunction= ruleParameterFunction EOF )
            // InternalCplus.g:2205:2: iv_ruleParameterFunction= ruleParameterFunction EOF
            {
             newCompositeNode(grammarAccess.getParameterFunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParameterFunction=ruleParameterFunction();

            state._fsp--;

             current =iv_ruleParameterFunction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParameterFunction"


    // $ANTLR start "ruleParameterFunction"
    // InternalCplus.g:2211:1: ruleParameterFunction returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_pass_1_0= ruleTypePass ) ) ( (lv_variable_2_0= ruleVariable ) ) ) ;
    public final EObject ruleParameterFunction() throws RecognitionException {
        EObject current = null;

        EObject lv_type_0_0 = null;

        EObject lv_pass_1_0 = null;

        EObject lv_variable_2_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2217:2: ( ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_pass_1_0= ruleTypePass ) ) ( (lv_variable_2_0= ruleVariable ) ) ) )
            // InternalCplus.g:2218:2: ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_pass_1_0= ruleTypePass ) ) ( (lv_variable_2_0= ruleVariable ) ) )
            {
            // InternalCplus.g:2218:2: ( ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_pass_1_0= ruleTypePass ) ) ( (lv_variable_2_0= ruleVariable ) ) )
            // InternalCplus.g:2219:3: ( (lv_type_0_0= ruleTypeVariable ) ) ( (lv_pass_1_0= ruleTypePass ) ) ( (lv_variable_2_0= ruleVariable ) )
            {
            // InternalCplus.g:2219:3: ( (lv_type_0_0= ruleTypeVariable ) )
            // InternalCplus.g:2220:4: (lv_type_0_0= ruleTypeVariable )
            {
            // InternalCplus.g:2220:4: (lv_type_0_0= ruleTypeVariable )
            // InternalCplus.g:2221:5: lv_type_0_0= ruleTypeVariable
            {

            					newCompositeNode(grammarAccess.getParameterFunctionAccess().getTypeTypeVariableParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_33);
            lv_type_0_0=ruleTypeVariable();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParameterFunctionRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"ovanes.cplusdsl.Cplus.TypeVariable");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:2238:3: ( (lv_pass_1_0= ruleTypePass ) )
            // InternalCplus.g:2239:4: (lv_pass_1_0= ruleTypePass )
            {
            // InternalCplus.g:2239:4: (lv_pass_1_0= ruleTypePass )
            // InternalCplus.g:2240:5: lv_pass_1_0= ruleTypePass
            {

            					newCompositeNode(grammarAccess.getParameterFunctionAccess().getPassTypePassParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_pass_1_0=ruleTypePass();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParameterFunctionRule());
            					}
            					set(
            						current,
            						"pass",
            						lv_pass_1_0,
            						"ovanes.cplusdsl.Cplus.TypePass");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:2257:3: ( (lv_variable_2_0= ruleVariable ) )
            // InternalCplus.g:2258:4: (lv_variable_2_0= ruleVariable )
            {
            // InternalCplus.g:2258:4: (lv_variable_2_0= ruleVariable )
            // InternalCplus.g:2259:5: lv_variable_2_0= ruleVariable
            {

            					newCompositeNode(grammarAccess.getParameterFunctionAccess().getVariableVariableParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_variable_2_0=ruleVariable();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getParameterFunctionRule());
            					}
            					set(
            						current,
            						"variable",
            						lv_variable_2_0,
            						"ovanes.cplusdsl.Cplus.Variable");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParameterFunction"


    // $ANTLR start "entryRuleFunction"
    // InternalCplus.g:2280:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalCplus.g:2280:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalCplus.g:2281:2: iv_ruleFunction= ruleFunction EOF
            {
             newCompositeNode(grammarAccess.getFunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;

             current =iv_ruleFunction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalCplus.g:2287:1: ruleFunction returns [EObject current=null] : (otherlv_0= 'function' ( (lv_type_1_0= ruleTypeVariable ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )? otherlv_7= ')' ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )? otherlv_10= 'return' ( (lv_return_11_0= rulevalue ) ) otherlv_12= 'endfunction' ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        EObject lv_type_1_0 = null;

        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_parameterfunction_4_0 = null;

        EObject lv_parameterfunction_6_0 = null;

        EObject lv_statements_8_0 = null;

        EObject lv_statements_9_0 = null;

        EObject lv_return_11_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2293:2: ( (otherlv_0= 'function' ( (lv_type_1_0= ruleTypeVariable ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )? otherlv_7= ')' ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )? otherlv_10= 'return' ( (lv_return_11_0= rulevalue ) ) otherlv_12= 'endfunction' ) )
            // InternalCplus.g:2294:2: (otherlv_0= 'function' ( (lv_type_1_0= ruleTypeVariable ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )? otherlv_7= ')' ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )? otherlv_10= 'return' ( (lv_return_11_0= rulevalue ) ) otherlv_12= 'endfunction' )
            {
            // InternalCplus.g:2294:2: (otherlv_0= 'function' ( (lv_type_1_0= ruleTypeVariable ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )? otherlv_7= ')' ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )? otherlv_10= 'return' ( (lv_return_11_0= rulevalue ) ) otherlv_12= 'endfunction' )
            // InternalCplus.g:2295:3: otherlv_0= 'function' ( (lv_type_1_0= ruleTypeVariable ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )? otherlv_7= ')' ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )? otherlv_10= 'return' ( (lv_return_11_0= rulevalue ) ) otherlv_12= 'endfunction'
            {
            otherlv_0=(Token)match(input,59,FOLLOW_34); 

            			newLeafNode(otherlv_0, grammarAccess.getFunctionAccess().getFunctionKeyword_0());
            		
            // InternalCplus.g:2299:3: ( (lv_type_1_0= ruleTypeVariable ) )
            // InternalCplus.g:2300:4: (lv_type_1_0= ruleTypeVariable )
            {
            // InternalCplus.g:2300:4: (lv_type_1_0= ruleTypeVariable )
            // InternalCplus.g:2301:5: lv_type_1_0= ruleTypeVariable
            {

            					newCompositeNode(grammarAccess.getFunctionAccess().getTypeTypeVariableParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_type_1_0=ruleTypeVariable();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFunctionRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"ovanes.cplusdsl.Cplus.TypeVariable");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalCplus.g:2318:3: ( (lv_name_2_0= ruleEString ) )
            // InternalCplus.g:2319:4: (lv_name_2_0= ruleEString )
            {
            // InternalCplus.g:2319:4: (lv_name_2_0= ruleEString )
            // InternalCplus.g:2320:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getFunctionAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_7);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFunctionRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,17,FOLLOW_35); 

            			newLeafNode(otherlv_3, grammarAccess.getFunctionAccess().getLeftParenthesisKeyword_3());
            		
            // InternalCplus.g:2341:3: ( ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )* )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( ((LA39_0>=34 && LA39_0<=38)) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalCplus.g:2342:4: ( (lv_parameterfunction_4_0= ruleParameterFunction ) ) (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )*
                    {
                    // InternalCplus.g:2342:4: ( (lv_parameterfunction_4_0= ruleParameterFunction ) )
                    // InternalCplus.g:2343:5: (lv_parameterfunction_4_0= ruleParameterFunction )
                    {
                    // InternalCplus.g:2343:5: (lv_parameterfunction_4_0= ruleParameterFunction )
                    // InternalCplus.g:2344:6: lv_parameterfunction_4_0= ruleParameterFunction
                    {

                    						newCompositeNode(grammarAccess.getFunctionAccess().getParameterfunctionParameterFunctionParserRuleCall_4_0_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_parameterfunction_4_0=ruleParameterFunction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFunctionRule());
                    						}
                    						add(
                    							current,
                    							"parameterfunction",
                    							lv_parameterfunction_4_0,
                    							"ovanes.cplusdsl.Cplus.ParameterFunction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:2361:4: (otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) ) )*
                    loop38:
                    do {
                        int alt38=2;
                        int LA38_0 = input.LA(1);

                        if ( (LA38_0==16) ) {
                            alt38=1;
                        }


                        switch (alt38) {
                    	case 1 :
                    	    // InternalCplus.g:2362:5: otherlv_5= ',' ( (lv_parameterfunction_6_0= ruleParameterFunction ) )
                    	    {
                    	    otherlv_5=(Token)match(input,16,FOLLOW_34); 

                    	    					newLeafNode(otherlv_5, grammarAccess.getFunctionAccess().getCommaKeyword_4_1_0());
                    	    				
                    	    // InternalCplus.g:2366:5: ( (lv_parameterfunction_6_0= ruleParameterFunction ) )
                    	    // InternalCplus.g:2367:6: (lv_parameterfunction_6_0= ruleParameterFunction )
                    	    {
                    	    // InternalCplus.g:2367:6: (lv_parameterfunction_6_0= ruleParameterFunction )
                    	    // InternalCplus.g:2368:7: lv_parameterfunction_6_0= ruleParameterFunction
                    	    {

                    	    							newCompositeNode(grammarAccess.getFunctionAccess().getParameterfunctionParameterFunctionParserRuleCall_4_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_parameterfunction_6_0=ruleParameterFunction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getFunctionRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"parameterfunction",
                    	    								lv_parameterfunction_6_0,
                    	    								"ovanes.cplusdsl.Cplus.ParameterFunction");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop38;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_7=(Token)match(input,18,FOLLOW_36); 

            			newLeafNode(otherlv_7, grammarAccess.getFunctionAccess().getRightParenthesisKeyword_5());
            		
            // InternalCplus.g:2391:3: ( ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )* )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( ((LA41_0>=RULE_STRING && LA41_0<=RULE_ID)||(LA41_0>=20 && LA41_0<=22)||(LA41_0>=25 && LA41_0<=26)||LA41_0==30||(LA41_0>=34 && LA41_0<=38)) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalCplus.g:2392:4: ( (lv_statements_8_0= ruleStatements ) ) ( (lv_statements_9_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:2392:4: ( (lv_statements_8_0= ruleStatements ) )
                    // InternalCplus.g:2393:5: (lv_statements_8_0= ruleStatements )
                    {
                    // InternalCplus.g:2393:5: (lv_statements_8_0= ruleStatements )
                    // InternalCplus.g:2394:6: lv_statements_8_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getFunctionAccess().getStatementsStatementsParserRuleCall_6_0_0());
                    					
                    pushFollow(FOLLOW_36);
                    lv_statements_8_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFunctionRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_8_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:2411:4: ( (lv_statements_9_0= ruleStatements ) )*
                    loop40:
                    do {
                        int alt40=2;
                        int LA40_0 = input.LA(1);

                        if ( ((LA40_0>=RULE_STRING && LA40_0<=RULE_ID)||(LA40_0>=20 && LA40_0<=22)||(LA40_0>=25 && LA40_0<=26)||LA40_0==30||(LA40_0>=34 && LA40_0<=38)) ) {
                            alt40=1;
                        }


                        switch (alt40) {
                    	case 1 :
                    	    // InternalCplus.g:2412:5: (lv_statements_9_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:2412:5: (lv_statements_9_0= ruleStatements )
                    	    // InternalCplus.g:2413:6: lv_statements_9_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getFunctionAccess().getStatementsStatementsParserRuleCall_6_1_0());
                    	    					
                    	    pushFollow(FOLLOW_36);
                    	    lv_statements_9_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getFunctionRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_9_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop40;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_10=(Token)match(input,60,FOLLOW_12); 

            			newLeafNode(otherlv_10, grammarAccess.getFunctionAccess().getReturnKeyword_7());
            		
            // InternalCplus.g:2435:3: ( (lv_return_11_0= rulevalue ) )
            // InternalCplus.g:2436:4: (lv_return_11_0= rulevalue )
            {
            // InternalCplus.g:2436:4: (lv_return_11_0= rulevalue )
            // InternalCplus.g:2437:5: lv_return_11_0= rulevalue
            {

            					newCompositeNode(grammarAccess.getFunctionAccess().getReturnValueParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_37);
            lv_return_11_0=rulevalue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFunctionRule());
            					}
            					set(
            						current,
            						"return",
            						lv_return_11_0,
            						"ovanes.cplusdsl.Cplus.value");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_12=(Token)match(input,61,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getFunctionAccess().getEndfunctionKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleMethod"
    // InternalCplus.g:2462:1: entryRuleMethod returns [EObject current=null] : iv_ruleMethod= ruleMethod EOF ;
    public final EObject entryRuleMethod() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMethod = null;


        try {
            // InternalCplus.g:2462:47: (iv_ruleMethod= ruleMethod EOF )
            // InternalCplus.g:2463:2: iv_ruleMethod= ruleMethod EOF
            {
             newCompositeNode(grammarAccess.getMethodRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMethod=ruleMethod();

            state._fsp--;

             current =iv_ruleMethod; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMethod"


    // $ANTLR start "ruleMethod"
    // InternalCplus.g:2469:1: ruleMethod returns [EObject current=null] : (otherlv_0= 'method' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )? otherlv_6= ')' ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )? otherlv_9= 'endmethod' ) ;
    public final EObject ruleMethod() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_parameterfunction_3_0 = null;

        EObject lv_parameterfunction_5_0 = null;

        EObject lv_statements_7_0 = null;

        EObject lv_statements_8_0 = null;



        	enterRule();

        try {
            // InternalCplus.g:2475:2: ( (otherlv_0= 'method' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )? otherlv_6= ')' ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )? otherlv_9= 'endmethod' ) )
            // InternalCplus.g:2476:2: (otherlv_0= 'method' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )? otherlv_6= ')' ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )? otherlv_9= 'endmethod' )
            {
            // InternalCplus.g:2476:2: (otherlv_0= 'method' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )? otherlv_6= ')' ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )? otherlv_9= 'endmethod' )
            // InternalCplus.g:2477:3: otherlv_0= 'method' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )? otherlv_6= ')' ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )? otherlv_9= 'endmethod'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getMethodAccess().getMethodKeyword_0());
            		
            // InternalCplus.g:2481:3: ( (lv_name_1_0= ruleEString ) )
            // InternalCplus.g:2482:4: (lv_name_1_0= ruleEString )
            {
            // InternalCplus.g:2482:4: (lv_name_1_0= ruleEString )
            // InternalCplus.g:2483:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getMethodAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_7);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMethodRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"ovanes.cplusdsl.Cplus.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,17,FOLLOW_35); 

            			newLeafNode(otherlv_2, grammarAccess.getMethodAccess().getLeftParenthesisKeyword_2());
            		
            // InternalCplus.g:2504:3: ( ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )* )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( ((LA43_0>=34 && LA43_0<=38)) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalCplus.g:2505:4: ( (lv_parameterfunction_3_0= ruleParameterFunction ) ) (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )*
                    {
                    // InternalCplus.g:2505:4: ( (lv_parameterfunction_3_0= ruleParameterFunction ) )
                    // InternalCplus.g:2506:5: (lv_parameterfunction_3_0= ruleParameterFunction )
                    {
                    // InternalCplus.g:2506:5: (lv_parameterfunction_3_0= ruleParameterFunction )
                    // InternalCplus.g:2507:6: lv_parameterfunction_3_0= ruleParameterFunction
                    {

                    						newCompositeNode(grammarAccess.getMethodAccess().getParameterfunctionParameterFunctionParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_parameterfunction_3_0=ruleParameterFunction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMethodRule());
                    						}
                    						add(
                    							current,
                    							"parameterfunction",
                    							lv_parameterfunction_3_0,
                    							"ovanes.cplusdsl.Cplus.ParameterFunction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:2524:4: (otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) ) )*
                    loop42:
                    do {
                        int alt42=2;
                        int LA42_0 = input.LA(1);

                        if ( (LA42_0==16) ) {
                            alt42=1;
                        }


                        switch (alt42) {
                    	case 1 :
                    	    // InternalCplus.g:2525:5: otherlv_4= ',' ( (lv_parameterfunction_5_0= ruleParameterFunction ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_34); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getMethodAccess().getCommaKeyword_3_1_0());
                    	    				
                    	    // InternalCplus.g:2529:5: ( (lv_parameterfunction_5_0= ruleParameterFunction ) )
                    	    // InternalCplus.g:2530:6: (lv_parameterfunction_5_0= ruleParameterFunction )
                    	    {
                    	    // InternalCplus.g:2530:6: (lv_parameterfunction_5_0= ruleParameterFunction )
                    	    // InternalCplus.g:2531:7: lv_parameterfunction_5_0= ruleParameterFunction
                    	    {

                    	    							newCompositeNode(grammarAccess.getMethodAccess().getParameterfunctionParameterFunctionParserRuleCall_3_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_parameterfunction_5_0=ruleParameterFunction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getMethodRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"parameterfunction",
                    	    								lv_parameterfunction_5_0,
                    	    								"ovanes.cplusdsl.Cplus.ParameterFunction");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop42;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,18,FOLLOW_38); 

            			newLeafNode(otherlv_6, grammarAccess.getMethodAccess().getRightParenthesisKeyword_4());
            		
            // InternalCplus.g:2554:3: ( ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )* )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( ((LA45_0>=RULE_STRING && LA45_0<=RULE_ID)||(LA45_0>=20 && LA45_0<=22)||(LA45_0>=25 && LA45_0<=26)||LA45_0==30||(LA45_0>=34 && LA45_0<=38)) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalCplus.g:2555:4: ( (lv_statements_7_0= ruleStatements ) ) ( (lv_statements_8_0= ruleStatements ) )*
                    {
                    // InternalCplus.g:2555:4: ( (lv_statements_7_0= ruleStatements ) )
                    // InternalCplus.g:2556:5: (lv_statements_7_0= ruleStatements )
                    {
                    // InternalCplus.g:2556:5: (lv_statements_7_0= ruleStatements )
                    // InternalCplus.g:2557:6: lv_statements_7_0= ruleStatements
                    {

                    						newCompositeNode(grammarAccess.getMethodAccess().getStatementsStatementsParserRuleCall_5_0_0());
                    					
                    pushFollow(FOLLOW_38);
                    lv_statements_7_0=ruleStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMethodRule());
                    						}
                    						add(
                    							current,
                    							"statements",
                    							lv_statements_7_0,
                    							"ovanes.cplusdsl.Cplus.Statements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalCplus.g:2574:4: ( (lv_statements_8_0= ruleStatements ) )*
                    loop44:
                    do {
                        int alt44=2;
                        int LA44_0 = input.LA(1);

                        if ( ((LA44_0>=RULE_STRING && LA44_0<=RULE_ID)||(LA44_0>=20 && LA44_0<=22)||(LA44_0>=25 && LA44_0<=26)||LA44_0==30||(LA44_0>=34 && LA44_0<=38)) ) {
                            alt44=1;
                        }


                        switch (alt44) {
                    	case 1 :
                    	    // InternalCplus.g:2575:5: (lv_statements_8_0= ruleStatements )
                    	    {
                    	    // InternalCplus.g:2575:5: (lv_statements_8_0= ruleStatements )
                    	    // InternalCplus.g:2576:6: lv_statements_8_0= ruleStatements
                    	    {

                    	    						newCompositeNode(grammarAccess.getMethodAccess().getStatementsStatementsParserRuleCall_5_1_0());
                    	    					
                    	    pushFollow(FOLLOW_38);
                    	    lv_statements_8_0=ruleStatements();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getMethodRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"statements",
                    	    							lv_statements_8_0,
                    	    							"ovanes.cplusdsl.Cplus.Statements");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop44;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_9=(Token)match(input,63,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getMethodAccess().getEndmethodKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMethod"


    // $ANTLR start "entryRuleTypePass"
    // InternalCplus.g:2602:1: entryRuleTypePass returns [EObject current=null] : iv_ruleTypePass= ruleTypePass EOF ;
    public final EObject entryRuleTypePass() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTypePass = null;


        try {
            // InternalCplus.g:2602:49: (iv_ruleTypePass= ruleTypePass EOF )
            // InternalCplus.g:2603:2: iv_ruleTypePass= ruleTypePass EOF
            {
             newCompositeNode(grammarAccess.getTypePassRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypePass=ruleTypePass();

            state._fsp--;

             current =iv_ruleTypePass; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypePass"


    // $ANTLR start "ruleTypePass"
    // InternalCplus.g:2609:1: ruleTypePass returns [EObject current=null] : (otherlv_0= 'E' | otherlv_1= 'E/S' ) ;
    public final EObject ruleTypePass() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalCplus.g:2615:2: ( (otherlv_0= 'E' | otherlv_1= 'E/S' ) )
            // InternalCplus.g:2616:2: (otherlv_0= 'E' | otherlv_1= 'E/S' )
            {
            // InternalCplus.g:2616:2: (otherlv_0= 'E' | otherlv_1= 'E/S' )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==41) ) {
                alt46=1;
            }
            else if ( (LA46_0==64) ) {
                alt46=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // InternalCplus.g:2617:3: otherlv_0= 'E'
                    {
                    otherlv_0=(Token)match(input,41,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getTypePassAccess().getEKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalCplus.g:2622:3: otherlv_1= 'E/S'
                    {
                    otherlv_1=(Token)match(input,64,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getTypePassAccess().getESKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypePass"

    // Delegated rules


    protected DFA4 dfa4 = new DFA4(this);
    protected DFA6 dfa6 = new DFA6(this);
    static final String dfa_1s = "\15\uffff";
    static final String dfa_2s = "\1\5\1\uffff\2\7\11\uffff";
    static final String dfa_3s = "\1\46\1\uffff\2\72\11\uffff";
    static final String dfa_4s = "\1\uffff\1\1\2\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\2\1\3";
    static final String dfa_5s = "\15\uffff}>";
    static final String[] dfa_6s = {
            "\1\2\1\3\15\uffff\1\4\1\5\1\6\2\uffff\1\7\1\10\3\uffff\1\11\3\uffff\5\1",
            "",
            "\1\14\11\uffff\1\13\1\uffff\1\14\45\uffff\2\12",
            "\1\14\11\uffff\1\13\1\uffff\1\14\45\uffff\2\12",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "192:2: (this_DeclarationVariable_0= ruleDeclarationVariable | this_CallFunction_1= ruleCallFunction | this_Assignment_2= ruleAssignment | this_Write_3= ruleWrite | this_Read_4= ruleRead | this_If_5= ruleIf | this_While_6= ruleWhile | this_Repeat_7= ruleRepeat | this_From_8= ruleFrom | this_Increment_9= ruleIncrement )";
        }
    }
    static final String dfa_7s = "\1\uffff\2\12\2\uffff\1\14\7\uffff";
    static final String dfa_8s = "\1\4\2\5\1\uffff\1\11\1\5\7\uffff";
    static final String dfa_9s = "\1\54\2\77\1\uffff\1\50\1\77\7\uffff";
    static final String dfa_10s = "\3\uffff\1\3\2\uffff\1\5\1\6\1\7\1\10\1\2\1\1\1\4";
    static final String[] dfa_11s = {
            "\1\11\1\1\1\2\1\uffff\1\3\1\5\7\uffff\1\7\25\uffff\1\4\1\6\2\uffff\2\10",
            "\3\12\7\uffff\1\12\1\uffff\1\13\1\12\1\uffff\24\12\5\uffff\14\12\3\uffff\2\12\1\uffff\1\12",
            "\3\12\7\uffff\1\12\1\uffff\1\13\1\12\1\uffff\24\12\5\uffff\14\12\3\uffff\2\12\1\uffff\1\12",
            "",
            "\1\5\36\uffff\1\6",
            "\2\14\10\uffff\1\14\2\uffff\1\14\1\uffff\24\14\1\6\4\uffff\14\14\3\uffff\2\14\1\uffff\1\14",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };
    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[][] dfa_11 = unpackEncodedStringArray(dfa_11s);

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = dfa_1;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_5;
            this.transition = dfa_11;
        }
        public String getDescription() {
            return "407:2: (this_CallFunction_0= ruleCallFunction | this_VariableID_1= ruleVariableID | this_ConstString_2= ruleConstString | this_Integer_3= ruleInteger | this_IntDecimal_4= ruleIntDecimal | this_operation_5= ruleoperation | this_ValBoolean_6= ruleValBoolean | this_Character_7= ruleCharacter )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x4800000000004000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000007C46708060L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000198000040370L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000050000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000198000000370L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000080080L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000198000020370L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0100007C47700060L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000007C4E700060L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000007C56700060L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000007E46700060L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0600000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000010000000200L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000060000000002L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000008000000200L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x00FFE08000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000007C46700062L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000007C00000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000007C00040000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x1000007C46700060L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x8000007C46700060L});

}