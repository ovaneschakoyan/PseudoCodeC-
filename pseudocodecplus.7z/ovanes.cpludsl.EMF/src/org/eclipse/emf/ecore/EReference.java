package org.eclipse.emf.ecore;

public interface EReference {

}
