package org.eclipse.emf.common.util;

public interface Enumerator {

}
