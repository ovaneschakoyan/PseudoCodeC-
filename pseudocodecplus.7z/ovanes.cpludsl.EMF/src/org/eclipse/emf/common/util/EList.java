package org.eclipse.emf.common.util;

public class EList {

}
