package ovanes.cpludsl;

public interface Character extends Operator 
{

	public String getContent();
	
	public void setContent(String value);
}
