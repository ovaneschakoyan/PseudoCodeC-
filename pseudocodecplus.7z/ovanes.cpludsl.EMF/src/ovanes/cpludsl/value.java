package ovanes.cpludsl;

public class value {

}
