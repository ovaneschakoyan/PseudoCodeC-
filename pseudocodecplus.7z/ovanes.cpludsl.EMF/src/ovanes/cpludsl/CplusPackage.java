package ovanes.cpludsl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;



public interface CplusPackage extends EPackage
{
  String eName = "cplus";
  
  String eNS_URI = "http://www.cplusdsl.ovanes/Cplus";
  
  String eNS_PREFIX ="cplus";
  
  CplusPackage eINSTANCE = ovanes.cpludsl.cpludsl.impl.CplusPackageImpl.init();
  
  int CODE = 0;
  
  int CODE_HAS = 0;
  
  int CODE_FUNCTION=0;
  
  int CODE_NAME = 2;
  
  int CODE_FEATURE_COUNT = 3;
  
  
}
