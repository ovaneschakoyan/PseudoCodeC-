package ovanes.cpludsl;

import org.eclipse.emf.common.util.Enumerator;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Boolean implements Enumerator
{
  
	TRUE(0,"true","true"),
	FALSE(1,"false","false");
	
	public static final int TRUE_VALUE=0;
	public static final int FALSE_VALUE=1;
	private static final boolean[] VALUES_ARRAY = new boolean[] {TRUE,FALSE};
	
	public static final List<boolean> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));
	
	public static boolean get(String literal)
	{
		for(int i=0;i<VALUES_ARRAY.length;++i)
		{
			boolean result = VALUES_ARRAY[i];
			if(result.toString().equals(literal))
			{
				return result;
			}
		}
		return null;
	}
	
	public static boolean getByName(String name)
	{
	for(int i=0;i<VALUES_ARRAY.length;++i)
	{
		boolean result = VALUES_ARRAY[i];
		if(result.getName().equals(name))
		{
			return result;
		}
		
	}
	return null;
	}
	
	public static boolean get(int value)
	{
		switch(value)
		{
		case TRUE_VALUE:return TRUE;
		case FALSE_VALUE:return FALSE;
		}
		return null;
	}
	
	private final int value;
	private final String name;
	private final String literal;
	private boolean (int value,String name,String literal)
	{
		this.value=value;
		this.name=name;
		this.literal=literal;
	}
	
	public int getValue()
	{
		return value;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getLiteral()
	{
		return literal
	}
	
	@Override
	public String toString()
	{
		return literal;
	}
}


