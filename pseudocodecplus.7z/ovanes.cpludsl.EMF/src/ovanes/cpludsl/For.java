package ovanes.cpludsl;

public interface For extends Block
{
  public Assignment getAssignment();
  
  public void setAssignment(Assignment value);
}
