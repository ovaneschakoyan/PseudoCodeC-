package ovanes.cpludsl;

import org.eclipse.emf.ecore.EObject;

public interface string extends EObject {

}
