package ovanes.cpludsl;

import org.eclipse.emf.common.util.EList;

public interface Block extends Statements
{

	value getValue();
	
	public void setValue(value value);
	
	EList<Statements> getStatements();
	
	
}
