package ovanes.cpludsl;

public interface Statements {

}
