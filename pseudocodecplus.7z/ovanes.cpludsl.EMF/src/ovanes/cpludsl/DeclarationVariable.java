package ovanes.cpludsl;

public interface DeclarationVariable extends Statements
{

	public TypeVariable getType();
	
	public void setType(TypeVariable value);
	
	EList<Variable> getContainsIDs();
}
