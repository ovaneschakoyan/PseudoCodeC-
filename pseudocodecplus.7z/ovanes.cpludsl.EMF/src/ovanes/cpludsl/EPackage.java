package ovanes.cpludsl;

public interface EPackage {

}
