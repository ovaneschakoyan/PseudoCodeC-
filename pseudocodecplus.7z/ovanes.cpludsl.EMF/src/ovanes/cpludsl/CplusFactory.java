package ovanes.cpludsl;

import org.eclipse.emf.ecore.EFactory;

public interface CplusFactory extends EFactory {

	CplusFactory eINSTANCE = cplus.impl.CplusFactoryImpl.init();
	
	Code createCode();
	Initiation createInitiation();
	DeclarationVariable createDeclaration();
	CallFunction createCallFunction();
	VariableID createVariableID();
	string createstring();
	ConstString createConstString();
	Variable createVariable();
	Integer createInteger();
	Assignment createAssignment();
	Write createWrite();
	Function createFunction();
	ParameterFunction createParameterFunction();
	Read createRead();
	IntDecimal createIntDecimal();
	operation createoperation();
	operator_left createoperator_left();
	operator_right createoperator_right();
	ValBoolean createValBoolean();
	If createIf();
	Else createElse();
	while createwhile();
	do createdo();
	for createfor();
	increment createincrement();
	Method createMethod();
	Character createCharacter();
	
	CplusPackage getCplusPackage();
}
