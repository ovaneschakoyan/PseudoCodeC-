package ovanes.cpludsl;

import org.eclipse.emf.common.util.EList;

public interface Assignment extends Statements
{
 String getLvalue();
 
 public void setLvalue(String value);
 
 value getOperator();
 
 public void setOperator(value value);
 
 EList<String> getMat();
 
}
