package ovanes.cpludsl;

public interface ConstStirng extends Operator
{

	public String getContent();
	
	public void setContent(String value);
	
	
}
