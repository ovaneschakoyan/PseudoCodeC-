package ovanes.cpludsl;

import org.eclipse.emf.common.util.EList;

public interface Code extends EObject {

	public Initiation getHas();
	
	public void setHas(Initiation value);
	
	EList<Thread> getFunction();
	
	public String getName();
	
	public void setName(String value);
}
