package ovanes.cpludsl;

public interface cpludsl {

	Object impl = null;

}
